"""M2 观战窗口：pygame 透视 3D 渲染 + 机体模型 + 机动标签，只读 World 状态。

相机围绕两机连线的中点做轨道飞行，俯角约 26°，地面网格和竖直投影线
用来给出高度的直观参照；机体用对应的三维模型表示，姿态直接取内核的
psi/theta/phi（点质量内核用 gamma/-bank 还原），开火时叠加炮口焰与炮线。
"""
from __future__ import annotations

import math
import os
from array import array

import numpy as np
import pygame

from sim import (
    CONTACT_DETECT,
    CONTACT_TRACK,
    G,
    RADAR_DETECT_FOV,
    World,
    air_density,
    body_axes,
    clamp,
    gun_direction,
    nose_direction,
    predict_position,
    rcs_scale,
    world_velocity,
    wrap_pi,
)

# 主界面配色：底色压深压冷，文字、机体和航迹统一提高明度，这样叠上半透明
# 面板、地形图之后仍然读得清；红方偏橙红、蓝方偏亮青蓝，与 HUD 绿、告警黄
# 和地形图的青灰都不会混色。
BG = (11, 15, 21)
GRID = (34, 44, 58)
BORDER = (82, 96, 114)
TEXT = (238, 243, 250)
SUB = (158, 170, 186)
TEAM_COLORS = ((255, 116, 96), (92, 178, 255))
# 抬头显示仪的通用色板：主绿 = 地平线/刻度/读数，暗绿 = 细刻度，
# 琥珀 = 当前值方框、水平标志与机炮落点，红 = 来袭告警。
HUD_GREEN = (132, 236, 178)
HUD_DIM = (74, 140, 106)
HUD_MARK = (255, 214, 120)
HUD_WARN = (255, 96, 84)
# 轨迹采样间距：整场都保留，但按距离抽点，避免几千段线拖慢每帧。
TRAIL_SPACING = 60.0
# 航迹飘带半宽（屏幕像素）：按相机深度换算成世界尺度，保证镜头拉近拉远时
# 飘带都有稳定的可见厚度，而不是一条 1–2 px 的细线。
TRAIL_HALF_PX = 5.0
# 航迹飘带的“天光”方向（右上前方）：飘带法向与它越接近越亮，
# 飞机滚转、倒扣时法向随之转动，飘带就出现明暗起伏。
TRAIL_LIGHT = (-0.35, -0.55, 0.76)
# 飘带按“年龄”渐变的时间窗口：最近这么久以内的段保持高亮，更旧的逐渐
# 淡出。窗口越短，越像一条会拖尾的发光航迹，机动动作的先后顺序越清楚。
TRAIL_FADE_TIME = 12.0
# 开火点抽稀：同一个点射不必每一帧都插一个标记。
SHOT_SPACING = 120.0
# 每隔多少个采样点放一个方向箭头。
ARROW_EVERY = 25

# ---- 轨迹上的事件标记（实时画在 3D 航迹线上，不是事后出图） ----
# 金色星标 = 导弹发射点；橙色菱形 = 高 G 机动点。
LAUNCH_MARK = (255, 209, 102)
HIGH_G_MARK_COLOR = (255, 122, 69)
# 过载超过人体可持续耐受（6 g）即标注；高空升力受限时（9–12 km、300 m/s
# 量级）可用过载本身只有 4–5 g，因此执行高 G 原语且拉到当地可用过载的
# 75% 也标注，否则航迹上几乎看不到高 G 点（与 main.py 一致）。
HIGH_G_LOAD = 6.0
HIGH_G_REL = 0.75
HIGH_G_COOLDOWN = 1.5

# 导弹的等效 RCS：弹体只有 3–4 m 长、0.2 m 粗，迎头回波约 0.05 m² 量级。
# 机载雷达探测距离按 RCS 的四次方根缩放，因此对弹的发现距离只有对 1 m²
# 目标时的约 0.47 倍（Su-57 约 75 km、F-16V 约 33 km）。
MISSILE_RCS = 0.05

NEAR = 1.0
FOV = math.radians(50.0)
# 屏幕尺寸统一参考长度：用 Su-57 的真实机长做基准，F-16 自动缩到它的 0.75，
# 两机在画面上呈现真实的大小比例关系。
REF_LENGTH = 20.1
# 固定方向光，给机体多边形做明暗，避免纯色剪影。
LIGHT = (-0.35, -0.55, 0.76)


# ---------- GPU（OpenGL 3.3 core）渲染 ----------
# 3D 场景（地面网格、航迹、机体、姿态框模型）交给 OpenGL 绘制，pygame 仍然
# 负责窗口/输入与 2D HUD：每帧把 HUD 画在透明 Surface 上，再作为纹理叠到 GL 画面。
LIT_VS = """#version 330
uniform mat4 u_mvp;
uniform mat4 u_rot;
uniform vec3 u_light;
in vec3 in_pos;
in vec3 in_nrm;
in vec3 in_col;
out vec3 v_col;
void main() {
    gl_Position = u_mvp * vec4(in_pos, 1.0);
    vec3 n = normalize(mat3(u_rot) * in_nrm);
    v_col = in_col * (0.62 + 0.38 * abs(dot(n, normalize(u_light))));
}
"""

LIT_FS = """#version 330
in vec3 v_col;
out vec4 f_col;
void main() { f_col = vec4(v_col, 1.0); }
"""

FLAT_VS = """#version 330
uniform mat4 u_mvp;
in vec3 in_pos;
in vec3 in_col;
out vec3 v_col;
void main() {
    gl_Position = u_mvp * vec4(in_pos, 1.0);
    v_col = in_col;
}
"""

HUD_VS = """#version 330
in vec2 in_pos;
in vec2 in_uv;
out vec2 v_uv;
void main() {
    gl_Position = vec4(in_pos, 0.0, 1.0);
    v_uv = in_uv;
}
"""

HUD_FS = """#version 330
uniform sampler2D u_tex;
in vec2 v_uv;
out vec4 f_col;
void main() { f_col = texture(u_tex, v_uv); }
"""


def _mat4_flat(rows) -> tuple:
    """行主序 4x4 → OpenGL 需要的列主序 16 元组（moderngl 按原始字节上传）。"""
    return tuple(rows[r][c] for c in range(4) for r in range(4))


def _mat4_mul(a, b) -> list:
    """行主序 4x4 矩阵相乘。"""
    return [
        [sum(a[r][k] * b[k][c] for k in range(4)) for c in range(4)]
        for r in range(4)
    ]


def _mix(a, b, t: float) -> tuple[int, int, int]:
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


# ---------- OBJ 机体模型 ----------

SU57_OBJ_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "I154-SU-57战机",
    "I154-SU-57战机_OBJ.obj",
)
# F-16C 的 OBJ 在 f_16c_model 目录下，原始单位就是米。
F16_OBJ_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "f_16c_model",
    "f_16c.obj",
)
# 座舱内部、仪表和起落架灯从外部视角看不到，读入时直接丢弃。
_DROP_MATERIALS = {
    # "pkfa-cockpit",
    # "pkfa-cockpit-Instr-glass",
    # "pkfa-Instr-glass",
    # "pkfa-hud",
    # "pkfa-cockpit-digits",
    # "pkfa-cockpit-ADIM",
    # "pkfa-landinglights",
}
_CANOPY_MATERIALS = {"pkfa-cockpit-glass"}
# 模型是起落架放下状态；机体系下低于 -0.10 的面属于起落架（机身最低约 -0.096）。
_GEAR_Y = -0.10

# F-16C 的 OBJ 带了一大堆外部挂载（副油箱、LITENING/Sniper 吊舱、GPU-5A 机炮吊舱、
# 各种挂架和座椅内饰）。只保留机体蒙皮与座舱玻璃，其余全部丢弃：既符合对局里的
# 武器挂载，又能把 28 万面降到可实时渲染的量级。
F16_KEEP_MATERIALS = {
    "f_16c_block_50_d_a_n_d_l_c_d_m_c_b",
    "dynamic_glass_chrome_d_o_0.17_c_d_g_c",
    "dynamic_glass_chrome_d_o_0.75_c_d_g_c",
    "dynamic_glass_chrome_d_o_0.2_c_d_g_c",
    "dynamic_glass_chrome_d_o_0.15_c_d_g_c",
    "dynamic_glass_chrome_d_o_0.1_c_d_g_c",
}
F16_CANOPY_MATERIALS = {
    "dynamic_glass_chrome_d_o_0.17_c_d_g_c",
    "dynamic_glass_chrome_d_o_0.75_c_d_g_c",
}
# 机体最低点约 -0.95 m，再往下是放下的起落架；切掉这些面让飞行姿态更干净。
F16_GEAR_Y = -0.95


def _load_obj_model(
    path: str,
    length: float,
    voxel: float,
    keep_materials: set | None = None,
    canopy_materials: set | None = None,
    gear_y: float | None = None,
) -> dict:
    """读取 OBJ 并做体素聚类简化，返回机体坐标系下的面列表。

    原始 OBJ 坐标：x 朝机头、z 为展向、y 向上，原点不在机身中心。
    这里统一缩放/平移成 (x 前, y 右, z 下)，与内核和渲染的机体系一致。
    """
    canopy_set = _CANOPY_MATERIALS if canopy_materials is None else canopy_materials
    verts = []
    faces = []
    material = None
    with open(path, "r", errors="ignore") as fh:
        for line in fh:
            if line.startswith("v "):
                px, py, pz = line.split()[1:4]
                verts.append((float(px), float(py), float(pz)))
            elif line.startswith("usemtl "):
                material = line.split(None, 1)[1].strip()
            elif line.startswith("f "):
                if material in _DROP_MATERIALS:
                    continue
                if keep_materials is not None and material not in keep_materials:
                    continue
                idx = [int(tok.split("/")[0]) - 1 for tok in line.split()[1:]]
                if gear_y is not None and min(verts[i][1] for i in idx) < gear_y:
                    continue
                faces.append((idx, material))

    used = sorted({i for idx, _ in faces for i in idx})
    xs = [verts[i][0] for i in used]
    ys = [verts[i][1] for i in used]
    zs = [verts[i][2] for i in used]
    cx = (min(xs) + max(xs)) / 2.0
    cy = (min(ys) + max(ys)) / 2.0
    cz = (min(zs) + max(zs)) / 2.0
    scale = length / (max(xs) - min(xs))

    # 体素聚类：同一格内的顶点合并到平均位置，面数从 4 万降到几千。
    buckets = {}
    for i in used:
        x, y, z = verts[i]
        key = (round(x / voxel), round(y / voxel), round(z / voxel))
        slot = buckets.get(key)
        if slot is None:
            buckets[key] = [x, y, z, 1]
        else:
            slot[0] += x
            slot[1] += y
            slot[2] += z
            slot[3] += 1

    remap = {}
    pts = []
    for k, (key, slot) in enumerate(buckets.items()):
        remap[key] = k
        pts.append((slot[0] / slot[3], slot[1] / slot[3], slot[2] / slot[3]))

    out = []
    seen = set()
    for idx, material in faces:
        cluster = []
        for i in idx:
            x, y, z = verts[i]
            c = remap[(round(x / voxel), round(y / voxel), round(z / voxel))]
            if c not in cluster:
                cluster.append(c)
        if len(cluster) < 3:
            continue
        sig = tuple(sorted(cluster))
        if sig in seen:
            continue
        seen.add(sig)
        poly = [
            ((pts[c][0] - cx) * scale,
             (pts[c][2] - cz) * scale,
             -(pts[c][1] - cy) * scale)
            for c in cluster
        ]
        kind = "canopy" if material in canopy_set else "body"
        out.append((poly, kind))
    return {"length": length, "faces": out, "cull": False, "outline": False}


# Su-57 直接用 SU-57 文件夹里的 OBJ，体素 0.05（约 0.5 m）：约 1500 面，
# 游戏里机体最多约 100 px，这个精度足够，还能保住 60 fps 以上。
# 长度取公开数据 20.1 m；F-16 取 15.06 m，两者屏幕上保持真实尺寸比例。
SU57_MODEL = _load_obj_model(SU57_OBJ_PATH, 20.1, 0.05, gear_y=_GEAR_Y)
# 双发尾喷口位置（机体系，x 向后、y 右、z 下），用于画尾焰。
SU57_MODEL["engines"] = [(-9.4, 0.7, 0.0), (-9.4, -0.7, 0.0)]

F16_MODEL = _load_obj_model(
    F16_OBJ_PATH, 15.06, 0.40,
    keep_materials=F16_KEEP_MATERIALS,
    canopy_materials=F16_CANOPY_MATERIALS,
    gear_y=F16_GEAR_Y,
)
F16_MODEL["engines"] = [(-7.30, 0.0, 0.0)]

MODEL_BY_NAME = {"SU-57": SU57_MODEL, "F-16V": F16_MODEL}
GENERIC_MODEL = SU57_MODEL

# ---------- 外部贴图资源（scripts/build_*.py 生成） ----------
_ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
# 城市地图（CityMapStudio 风格，覆盖 200 km × 200 km，与 main.py 的 arena 对齐）。
TERRAIN_ORTHO_PATH = os.path.join(_ASSET_DIR, "terrain", "city_ortho.png")
TERRAIN_SIZE_M = 200000.0
# 地面透视贴图的降采样步长（像素）：6 像素一格，放大后再做平滑。
GROUND_STEP = 6
# 武器页的机体俯视轮廓（由 OBJ 正交投影生成，机头朝上、透明底）。
SILHOUETTE_PATH = {
    "SU-57": os.path.join(_ASSET_DIR, "silhouette", "su57_top.png"),
    "F-16V": os.path.join(_ASSET_DIR, "silhouette", "f16_top.png"),
}

# 机体各部件的配色键 → 相对队伍色的明暗系数；座舱/进气道/喷口用独立颜色。
PART_SHADE = {
    "body": 1.0,
    "wing": 0.86,
    "tail": 0.76,
    "canopy": None,
    "intake": None,
    "nozzle": None,
}
CANOPY_COLOR = (126, 196, 238)
INTAKE_COLOR = (52, 56, 62)
NOZZLE_COLOR = (92, 88, 84)

# 武器页中央的本机俯视轮廓：只给右半侧（x 向前、y 向右，单位 = 机长），
# 左半侧在 aircraft_silhouette() 里镜像拼接。y 的最大值 = 翼展 / 机长 / 2，
# 因此轮廓的宽高比与真实机体一致（Su-57 约 14.1/20.1，F-16 约 9.96/15.06）。
SILHOUETTE_RIGHT = {
    "SU-57": (
        (0.50, 0.000), (0.43, 0.014), (0.26, 0.022), (0.08, 0.034),
        (-0.01, 0.081), (-0.06, 0.222), (-0.12, 0.322), (-0.20, 0.351),
        (-0.36, 0.298), (-0.27, 0.137), (-0.30, 0.060), (-0.44, 0.105),
        (-0.50, 0.085),
    ),
    "F-16V": (
        (0.50, 0.000), (0.44, 0.030), (0.28, 0.045), (0.10, 0.070),
        (0.01, 0.240), (-0.06, 0.330), (-0.14, 0.325),
        (-0.20, 0.200), (-0.22, 0.090), (-0.36, 0.200), (-0.47, 0.215),
        (-0.50, 0.130),
    ),
}


def aircraft_silhouette(name: str) -> list[tuple[float, float]]:
    """返回机型的闭合俯视轮廓（机头朝 +x），右半侧镜像出左半侧。"""
    right = SILHOUETTE_RIGHT.get(name, SILHOUETTE_RIGHT["SU-57"])
    return list(right) + [(p[0], -p[1]) for p in reversed(right)]


def attitude_of(ac) -> tuple[float, float, float]:
    """渲染用姿态 (psi, theta, phi)。点质量内核用航迹角与滚转角还原。"""
    if getattr(ac, "rigid", False):
        return ac.psi, ac.theta, ac.phi
    # 3DOF 的 bank>0 为左滚，而机体 phi>0 为右滚，故取负号。
    return ac.psi, ac.gamma, -ac.bank


def _attitude_basis():
    """姿态框的固定等距视角基向量（与 _draw_attitude_model 保持一致）。"""
    view = _norm((0.85, -0.98, 0.55))
    right = _norm(_cross((0.0, 0.0, 1.0), view))
    return view, right, _cross(view, right)



def _dot(a, b) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b) -> tuple[float, float, float]:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _norm(a) -> tuple[float, float, float]:
    n = math.sqrt(_dot(a, a)) or 1.0
    return (a[0] / n, a[1] / n, a[2] / n)


class Renderer:
    def __init__(
        self,
        size: tuple[int, int] = (1600, 1000),
        follow: int | None = None,
        follow_dist: float = 1800.0,
        gpu: bool = True,
        span_factor: float = 1.25,
    ) -> None:
        pygame.init()
        self.w, self.h = size
        # 3D 场景优先交给 OpenGL；没有可用 GL 上下文（远程会话/软件驱动）时
        # 自动回退到原来的 pygame 软件渲染，HUD 与交互完全一致。
        self.ctx = None
        self.mgl = None
        self.gpu = gpu and self._init_gpu(size)
        if not self.gpu:
            self.screen = pygame.display.set_mode(size)
        pygame.display.set_caption("Dogfight M2")
        self.font = pygame.font.Font(None, 22)
        self.font_small = pygame.font.Font(None, 18)
        self.font_big = pygame.font.Font(None, 64)

        # 轨道相机：yaw 绕世界 z 轴，pitch 抬高视线，dist 控制取景距离。
        self.cam = [0.0, 0.0, 1000.0]
        # 初始方位与“垂直于两机连线”的稳态一致，避免开局相机绕 180°。
        self.yaw = math.pi / 2.0
        self.pitch = math.radians(26.0)
        self.dist = 6000.0
        self.eye = (0.0, 6000.0, 3000.0)
        self.right = (1.0, 0.0, 0.0)
        self.up = (0.0, 0.0, 1.0)
        self.forward = (0.0, 1.0, 0.0)
        self.focal = (self.h / 2.0) / math.tan(FOV / 2.0)

        self.trails: list[list[tuple[float, float, float]]] = [[], []]
        # 每个航迹采样点的机体横向轴（机体 y 轴 = 翼展方向），用来把航迹
        # 画成一条与飞机机体 xy 平面一致的宽飘带，而不是屏幕上的细线。
        self.trail_axes: list[list[tuple[float, float, float]]] = [[], []]
        # 每个采样点的时刻，用于让飘带按“年龄”做渐变（最近的段最亮）。
        self.trail_t: list[list[float]] = [[], []]
        self.fire_marks: list[list[tuple[float, float, float]]] = [[], []]
        # 轨迹事件：导弹发射点 (队别, 位置) 与高 G 机动点 (队别, 位置)。
        self.launch_marks: list[tuple[int, tuple[float, float, float]]] = []
        self.highg_marks: list[tuple[int, tuple[float, float, float]]] = []
        self._seen_missiles: set[int] = set()
        self._highg_state = [False, False]
        self._last_highg = [-1e9, -1e9]
        self._last_sample: list[tuple[float, float, float] | None] = [None, None]
        self._last_shot: list[tuple[float, float, float] | None] = [None, None]
        # 在飞格斗弹的尾迹：按 id 记账，导弹结束后清掉。
        self.missile_trails: dict[int, list[tuple[float, float, float]]] = {}
        # 尾焰强度跟着真实推力走，0=收油门、1=满加力。
        self._flame = [0.35, 0.35]
        self.overlay = pygame.Surface(size, pygame.SRCALPHA)
        # 姿态框的屏幕矩形：GPU 模式下由 GL 在对应区域补画三维模型。
        self._attitude_rects: list[pygame.Rect] = []
        # 地面贴图：图像数组与逐帧投影缓存。
        self._ortho_arr = None
        self._ortho_tried = False
        # 武器页轮廓图（按机型和队伍预先着色、缩放后缓存）。
        self._sil_raw: dict[str, pygame.Surface | None] = {}
        self._sil_cache: dict[tuple, pygame.Surface] = {}
        self._cam_ready = False
        # 跟随模式：相机锁定某架飞机（默认关闭，仍取两机中点）。
        self.follow = follow
        self.follow_dist = follow_dist
        # 中点视角的取景倍率：1.25 让两机在 50° 视场内留约 6% 边距；
        # 演示视频可以再调小一点，把两机拍得更近。
        self.span_factor = span_factor

    # ---------- 相机与投影 ----------

    def update_camera(self, world: World) -> None:
        follow_ac = None if self.follow is None else world.acs[self.follow]
        alive = [ac for ac in world.acs if ac.alive] or world.acs
        if follow_ac is not None:
            cx, cy, cz = follow_ac.x, follow_ac.y, follow_ac.z
            target_dist = self.follow_dist
        else:
            k = len(alive)
            cx = sum(ac.x for ac in alive) / k
            cy = sum(ac.y for ac in alive) / k
            cz = sum(ac.z for ac in alive) / k
            a, b = world.acs
            sep_xy = math.hypot(b.x - a.x, b.y - a.y)
            span = max(sep_xy, abs(b.z - a.z) * 2.0, 1400.0)
            # 取景距离直接按两机间距缩放：120 km 开局时旧的上限 60 km 会把
            # 双方都推出画面，这里改成随间距线性放大（FOV 50° 下 1.25 倍间距
            # 留约 6% 边距），上限 320 km 覆盖 200 km 空域的对角。
            target_dist = clamp(span * self.span_factor, 2200.0, 320000.0)
        if self._cam_ready:
            self.dist += (target_dist - self.dist) * 0.06
            self.cam[0] += (cx - self.cam[0]) * 0.10
            self.cam[1] += (cy - self.cam[1]) * 0.10
            self.cam[2] += (cz - self.cam[2]) * 0.08
        else:
            # 首帧直接对焦，避免开局相机从原点一路飞过去。
            self.cam = [cx, cy, cz]
            self.dist = target_dist
            self._cam_ready = True

        if follow_ac is not None:
            # 机尾后方跟拍：视线方向跟着 SU-57 的航向转。
            desired = follow_ac.psi + math.pi
            self.yaw += clamp(wrap_pi(desired - self.yaw), -0.06, 0.06)
            self.pitch += (math.radians(16.0) - self.pitch) * 0.02
        elif sep_xy > 500.0:
            # 视线不严格垂直于两机连线，留约 20° 夹角，避免机翼在正对头时完全侧视消失。
            desired = (
                math.atan2(b.y - a.y, b.x - a.x) + math.pi / 2.0 - 0.35
            )
            self.yaw += clamp(wrap_pi(desired - self.yaw), -0.03, 0.03)

        cp, sp = math.cos(self.pitch), math.sin(self.pitch)
        self.eye = (
            self.cam[0] + self.dist * cp * math.cos(self.yaw),
            self.cam[1] + self.dist * cp * math.sin(self.yaw),
            self.cam[2] + self.dist * sp,
        )
        self.forward = _norm(
            (
                self.cam[0] - self.eye[0],
                self.cam[1] - self.eye[1],
                self.cam[2] - self.eye[2],
            )
        )
        self.right = _norm(_cross(self.forward, (0.0, 0.0, 1.0)))
        self.up = _cross(self.right, self.forward)

    def _view(self, p) -> tuple[float, float, float]:
        """世界坐标 → 相机坐标 (右, 上, 前)。"""
        rx, ry, rz = p[0] - self.eye[0], p[1] - self.eye[1], p[2] - self.eye[2]
        return (
            rx * self.right[0] + ry * self.right[1] + rz * self.right[2],
            rx * self.up[0] + ry * self.up[1] + rz * self.up[2],
            rx * self.forward[0] + ry * self.forward[1] + rz * self.forward[2],
        )

    def _screen_of(self, c) -> tuple[float, float]:
        return (
            self.w / 2.0 + self.focal * c[0] / c[2],
            self.h / 2.0 - self.focal * c[1] / c[2],
        )

    def to_screen(self, p) -> tuple[float, float] | None:
        c = self._view(p)
        if c[2] <= NEAR:
            return None
        return self._screen_of(c)

    def _clip_segment(self, p0, p1):
        """线段跨越近裁剪面时先截断，避免相机后方的东西被画到屏幕上。"""
        a, b = self._view(p0), self._view(p1)
        if a[2] <= NEAR and b[2] <= NEAR:
            return None
        if a[2] <= NEAR:
            t = (NEAR - a[2]) / (b[2] - a[2])
            a = tuple(a[i] + (b[i] - a[i]) * t for i in range(3))
        elif b[2] <= NEAR:
            t = (NEAR - b[2]) / (a[2] - b[2])
            b = tuple(b[i] + (a[i] - b[i]) * t for i in range(3))
        return self._screen_of(a), self._screen_of(b)

    def reset(self) -> None:
        self.trails = [[], []]
        self.trail_axes = [[], []]
        self.trail_t = [[], []]
        self.fire_marks = [[], []]
        self.launch_marks = []
        self.highg_marks = []
        self._seen_missiles = set()
        self._highg_state = [False, False]
        self._last_highg = [-1e9, -1e9]
        self._last_sample = [None, None]
        self._last_shot = [None, None]
        self.missile_trails = {}
        self._flame = [0.35, 0.35]
        self._attitude_rects = []

    def _record_trail(self, world: World, agents=None) -> None:
        """整局航迹都保留；按固定间距抽点，线段数量不会随帧率失控。

        同时记录两类事件，直接画在 3D 航迹线上：
        - 导弹发射点：第一次看到某个在飞弹 id 的时刻即发射瞬间；
        - 高 G 机动点：过载达到门限的上升沿，带 1.5 s 冷却避免连成一片。
        """
        for i, ac in enumerate(world.acs):
            if not ac.alive:
                continue
            p = (ac.x, ac.y, ac.z)
            last = self._last_sample[i]
            if last is None or math.dist(last, p) >= TRAIL_SPACING:
                self.trails[i].append(p)
                # 记录当时的机翼方向：飘带宽度沿机体 y 轴展开，
                # 因此飞机滚转/俯仰时飘带会跟着倾斜。
                _, yb, _ = body_axes(*attitude_of(ac))
                self.trail_axes[i].append(yb)
                self.trail_t[i].append(world.t)
                self._last_sample[i] = p
            if ac.firing:
                last_shot = self._last_shot[i]
                if last_shot is None or math.dist(last_shot, p) >= SHOT_SPACING:
                    self.fire_marks[i].append(p)
                    self._last_shot[i] = p

        for m in world.missiles:
            if m.alive and id(m) not in self._seen_missiles:
                self._seen_missiles.add(id(m))
                self.launch_marks.append((m.owner, (m.x, m.y, m.z)))

        for i, ac in enumerate(world.acs):
            primitive = getattr(agents[i], "primitive", "") if agents else ""
            n_avail = ac.spec.n_available(ac.v, ac.z, ac.mass) if ac.alive else 0.0
            hi = ac.alive and (
                ac.n >= HIGH_G_LOAD
                or (
                    primitive.startswith("HIGH_G")
                    and ac.n >= HIGH_G_REL * n_avail
                )
            )
            if (
                hi
                and not self._highg_state[i]
                and world.t - self._last_highg[i] > HIGH_G_COOLDOWN
            ):
                self._last_highg[i] = world.t
                self.highg_marks.append((i, (ac.x, ac.y, ac.z)))
            self._highg_state[i] = hi

    def _update_engines(self, world: World) -> None:
        """尾焰强度直接跟随当前推力：军推一档、加力一档，油尽自动掉回军推。"""
        for i, ac in enumerate(world.acs):
            if not ac.alive:
                target = 0.0
            else:
                frac = ac.thrust / max(ac.spec.thrust_max, 1.0)
                target = 0.10 + 0.90 * clamp(frac, 0.0, 1.0)
            self._flame[i] += (target - self._flame[i]) * 0.18

    # ---------- 绘制 ----------

    def draw(self, world: World, paused: bool = False, agents=None) -> None:
        self.update_camera(world)
        self.now = world.t
        self._record_trail(world, agents)
        self._update_engines(world)
        if self.gpu:
            # 2D 层先画在透明 HUD 面上，3D 场景由 GPU 渲染后再叠回 HUD。
            self.hud.fill((0, 0, 0, 0))
            self._draw_trails()
            self._draw_gun_envelopes(world)
            self._draw_aircraft(world, agents)
            self._draw_predictions(world)
            self._draw_missiles(world)
            self._draw_counters(world)
            self._draw_gunfire(world)
            self._draw_altitude_ladder(world)
            self._draw_hud(world, paused, agents)
            if world.result is not None:
                self._draw_result(world)
            self._gpu_scene(world)
            self._gpu_hud()
            self._gpu_attitude(world)
            pygame.display.flip()
            return

        self.screen.fill(BG)
        self._draw_ground(world)
        self._draw_floor(world.arena, world.z_floor)
        self._draw_trails()
        self._draw_gun_envelopes(world)
        self._draw_aircraft(world, agents)
        self._draw_predictions(world)
        self._draw_missiles(world)
        self._draw_counters(world)
        self._draw_gunfire(world)
        self._draw_altitude_ladder(world)
        self._draw_hud(world, paused, agents)

        if world.result is not None:
            self._draw_result(world)
        pygame.display.flip()

    def _ortho_image(self):
        """加载城市地图正交投影贴图，并预生成几级 mip，供远景采样用。

        远景时一个屏幕像素对应地面几百米，若直接从 2048 原图做最近邻采样，
        山体阴影会退化成满屏噪点；这里按地面采样密度选合适的 mip 层级。
        """
        if self._ortho_tried:
            return self._ortho_arr
        self._ortho_tried = True
        try:
            surf = pygame.image.load(TERRAIN_ORTHO_PATH).convert()
        except Exception:
            return None
        # surfarray 是 (宽, 高, 3)；转成 (高, 宽, 3)，行 0 对应地形图北侧。
        base = pygame.surfarray.array3d(surf).transpose(1, 0, 2).astype(np.uint8)
        mips = [base]
        while mips[-1].shape[0] >= 512:
            cur = mips[-1]
            h, w = cur.shape[:2]
            mips.append(
                cur.reshape(h // 2, 2, w // 2, 2, 3).mean(axis=(1, 3)).astype(np.uint8)
            )
        self._ortho_arr = mips
        return self._ortho_arr

    def _ground_image(self, world: World, step: int = GROUND_STEP):
        """把城市地图按当前相机透视投影到地面（z = z_floor）上。

        地面是平面，因此逐像素从屏幕发射线求与地面的交点，再换算成地形图
        UV 即可完成透视贴图。CPU 直接画时用低分辨率算完再放大，避免
        每帧对 160 万像素做 Python 循环。
        """
        mips = self._ortho_image()
        if mips is None:
            return None
        gw = max(2, self.w // step)
        gh = max(2, self.h // step)
        xs = (np.arange(gw, dtype=np.float64) + 0.5) * step
        ys = (np.arange(gh, dtype=np.float64) + 0.5) * step
        dxs = (xs - self.w * 0.5) / self.focal
        dys = (self.h * 0.5 - ys) / self.focal
        fx, fy, fz = self.forward
        rx, ry, rz = self.right
        ux, uy, uz = self.up

        dir_x = fx + dxs[None, :] * rx + dys[:, None] * ux
        dir_y = fy + dxs[None, :] * ry + dys[:, None] * uy
        dir_z = fz + dxs[None, :] * rz + dys[:, None] * uz
        depth = np.where(dir_z < -1e-9, np.minimum(dir_z, -1e-9), -1e-9)
        t = (float(world.z_floor) - self.eye[2]) / depth
        valid = (dir_z < -1e-9) & (t > 0.0)

        px = self.eye[0] + t * dir_x
        py = self.eye[1] + t * dir_y
        half = TERRAIN_SIZE_M * 0.5
        u = (px + half) / TERRAIN_SIZE_M
        v = (half - py) / TERRAIN_SIZE_M
        valid &= (u >= 0.0) & (u < 1.0) & (v >= 0.0) & (v < 1.0)

        # 按地面采样密度选 mip：一个屏幕像素对应的地面米数越大，用越粗的一级。
        span = float(np.percentile(t[valid], 70)) if bool(valid.any()) else 0.0
        base_texel = TERRAIN_SIZE_M / mips[0].shape[0]
        target = max(span / self.focal, base_texel)
        level = int(round(math.log2(target / base_texel)))
        level = max(0, min(level, len(mips) - 1))
        arr = mips[level]
        n = arr.shape[0]

        ix = np.clip((u * n).astype(np.int32), 0, n - 1)
        iy = np.clip((v * n).astype(np.int32), 0, n - 1)
        rgb = arr[iy, ix].astype(np.float32)
        # 远处地面混入冷灰雾，透视感更像真实航拍而不是硬贴一张图。
        haze = np.clip(t / 240000.0, 0.0, 0.45)[:, :, None]
        rgb = rgb * (1.0 - haze) + np.array((48.0, 66.0, 82.0)) * haze
        # 场景本身没有光照，补一点增益让地形细节从 HUD 底色里透出来。
        rgb = rgb * 1.12

        # 地形图边缘做一小段羽化，避免 200 km 图幅边界出现硬切边。
        edge = np.minimum(np.minimum(u, 1.0 - u), np.minimum(v, 1.0 - v))
        fade = np.clip(edge / 0.02, 0.0, 1.0)
        rgba = np.zeros((gh, gw, 4), dtype=np.uint8)
        rgba[:, :, :3] = np.clip(rgb, 0, 255).astype(np.uint8)
        rgba[:, :, 3] = np.where(valid, (fade * 255.0), 0.0).astype(np.uint8)
        return pygame.image.frombuffer(rgba.tobytes(), (gw, gh), "RGBA")

    def _draw_ground(self, world: World) -> None:
        """把城市地图地面层铺到 3D 场景最底层（地面网格仍画在它上面）。"""
        surf = self._ground_image(world)
        if surf is None:
            return
        gw, gh = surf.get_size()
        alpha = pygame.surfarray.array_alpha(surf).T
        rows = np.flatnonzero(alpha.any(axis=1))
        if rows.size == 0:
            return
        top_src = int(rows[0])
        # 地平线以上没有地面：只把有内容的行放大后贴上去，省掉一次全屏混合。
        cropped = surf.subsurface(pygame.Rect(0, top_src, gw, gh - top_src))
        top = top_src * GROUND_STEP
        self.screen.blit(
            pygame.transform.smoothscale(cropped, (self.w, self.h - top)), (0, top)
        )

    def _draw_floor(self, arena: float, z_floor: float = 0.0) -> None:
        """最低高度层网格 + 空域边界：高度读数的水平参照。"""
        half = arena / 2.0
        # 4 km 一格：贴了城市地图后，1 km 的密集网格会糊成一片摩尔纹，
        # 反而看不清地面；网格只作为空域尺度参照，不需要那么密。
        step = 4000.0
        x = -half
        while x <= half:
            seg = self._clip_segment((x, -half, z_floor), (x, half, z_floor))
            if seg:
                pygame.draw.line(self.screen, GRID, seg[0], seg[1], 1)
            x += step
        y = -half
        while y <= half:
            seg = self._clip_segment((-half, y, z_floor), (half, y, z_floor))
            if seg:
                pygame.draw.line(self.screen, GRID, seg[0], seg[1], 1)
            y += step

        corners = [(-half, -half), (half, -half), (half, half), (-half, half)]
        for i in range(4):
            p0 = (*corners[i], z_floor)
            p1 = (*corners[(i + 1) % 4], z_floor)
            seg = self._clip_segment(p0, p1)
            if seg:
                pygame.draw.line(self.screen, BORDER, seg[0], seg[1], 1)

    def _draw_trails(self) -> None:
        for i, trail in enumerate(self.trails):
            base = TEAM_COLORS[i]
            arrow_color = tuple(min(255, int(c * 1.05)) for c in base)
            if len(trail) >= 2:
                # GPU 模式下航迹线由 OpenGL 画，这里只保留箭头与事件标记。
                if not self.gpu:
                    axes = self.trail_axes[i]
                    ts = self.trail_t[i]
                    now = getattr(self, "now", 0.0)
                    # 宽飘带：每一段画成一个四边形，宽度方向取当时的机体
                    # y 轴（去掉沿切线的分量），因此飘带平面始终落在飞机
                    # 机体的 xy 平面内，飞机滚转/俯仰时飘带跟着倾斜。
                    # 颜色沿航迹渐变：按采样时刻做 22 s 拖尾，越新的段越亮，
                    # 旧段淡出，机动轨迹的先后顺序一眼可读。
                    for j in range(1, len(trail)):
                        axis = axes[j] if j < len(axes) else (0.0, 1.0, 0.0)
                        age = now - (ts[j] if j < len(ts) else now)
                        fade = max(0.0, 1.0 - age / TRAIL_FADE_TIME)
                        self._draw_trail_ribbon(
                            trail[j - 1], trail[j], axis, base, fade,
                        )

                # 方向箭头：沿航迹等距放箭标，整局走线在远看时也能读出方向。
                ts = self.trail_t[i]
                now = getattr(self, "now", 0.0)
                for j in range(ARROW_EVERY, len(trail), ARROW_EVERY):
                    s0 = self.to_screen(trail[j - 1])
                    s1 = self.to_screen(trail[j])
                    if s0 is not None and s1 is not None:
                        age = now - (ts[j] if j < len(ts) else now)
                        fade = max(0.0, 1.0 - age / TRAIL_FADE_TIME)
                        a_col = tuple(
                            int(c * (0.38 + 0.62 * fade)) for c in arrow_color
                        )
                        self._draw_arrow(s0, s1, a_col)

        # 开火点：每个点射位置留一个亮色菱形，和航迹一起构成完整战况记录。
        for marks in self.fire_marks:
            for p in marks:
                s = self.to_screen(p)
                if s is None:
                    continue
                x, y = s
                pygame.draw.polygon(
                    self.screen, (255, 190, 66),
                    [(x, y - 5), (x + 5, y), (x, y + 5), (x - 5, y)],
                )
                pygame.draw.line(
                    self.screen, (255, 246, 214), (x, y - 3), (x, y + 3), 1
                )

        # 导弹发射点：金色五角星 + 队伍色描边，位置就在发射瞬间的航迹点上。
        for owner, p in self.launch_marks:
            s = self.to_screen(p)
            if s is None:
                continue
            edge = tuple(int(c * 0.55) for c in TEAM_COLORS[owner])
            self._draw_star(s, 7.5, LAUNCH_MARK, edge)

        # 高 G 机动点：橙色菱形（比开火点大一号），同样落在 3D 航迹线上。
        for i, p in self.highg_marks:
            s = self.to_screen(p)
            if s is None:
                continue
            x, y = s
            pygame.draw.polygon(
                self.screen, HIGH_G_MARK_COLOR,
                [(x, y - 7), (x + 7, y), (x, y + 7), (x - 7, y)],
            )
            pygame.draw.polygon(
                self.screen, TEAM_COLORS[i],
                [(x, y - 4), (x + 4, y), (x, y + 4), (x - 4, y)], 1,
            )

    def _draw_star(self, s, size: float, fill, edge) -> None:
        """五角星：10 个顶点交替取外/内半径，用于导弹发射点。"""
        pts = []
        for k in range(10):
            ang = -math.pi / 2.0 + k * math.pi / 5.0
            r = size if k % 2 == 0 else size * 0.45
            pts.append((s[0] + r * math.cos(ang), s[1] + r * math.sin(ang)))
        pygame.draw.polygon(self.screen, fill, pts)
        pygame.draw.polygon(self.screen, edge, pts, 1)

    def _draw_trail_ribbon(
        self, p0, p1, y_axis, base: tuple[int, int, int], fade: float,
    ) -> None:
        """画一段航迹飘带：四边形宽度沿机体 y 轴，平面与机体 xy 平面一致。

        先把两端做近裁剪面裁剪；宽度方向取机体 y 轴在“垂直于航迹”的
        平面上的分量，再按当前相机深度换算成世界尺度，使屏幕厚度稳定在
        约 2×TRAIL_HALF_PX 像素。飘带侧对镜头时自然变窄，保留立体感。

        颜色做两层处理：
        - 渐变：``fade`` 从 0（最旧）到 1（最新），旧段变暗淡出；
        - 光影：飘带法向（机体 z 轴方向）与固定光求点积，飞机滚转/倒扣时
          法向随之转动，飘带亮度起伏，机动姿态因此更醒目。中心再叠一条
          更亮的高光芯，形成“宽边 + 亮芯”的立体观感。
        """
        a, b = self._view(p0), self._view(p1)
        if a[2] <= NEAR and b[2] <= NEAR:
            return
        if a[2] <= NEAR:
            t = (NEAR - a[2]) / (b[2] - a[2])
            a = tuple(a[k] + (b[k] - a[k]) * t for k in range(3))
        elif b[2] <= NEAR:
            t = (NEAR - b[2]) / (a[2] - b[2])
            b = tuple(b[k] + (a[k] - b[k]) * t for k in range(3))

        tx, ty, tz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        tl = math.sqrt(tx * tx + ty * ty + tz * tz)
        if tl < 1e-6:
            return
        tx, ty, tz = tx / tl, ty / tl, tz / tl
        d = y_axis[0] * tx + y_axis[1] * ty + y_axis[2] * tz
        ux, uy, uz = (
            y_axis[0] - tx * d, y_axis[1] - ty * d, y_axis[2] - tz * d,
        )
        ul = math.sqrt(ux * ux + uy * uy + uz * uz)
        if ul < 1e-6:
            return
        ux, uy, uz = ux / ul, uy / ul, uz / ul

        # 飘带法向 = 切线 × 展向（约等于机体 z 轴）。用固定方向的“天光”
        # 做单面着色：法向朝天（倒扣）时最亮，平飞时偏暗。
        nx = ty * uz - tz * uy
        ny = tz * ux - tx * uz
        nz = tx * uy - ty * ux
        lit = nx * TRAIL_LIGHT[0] + ny * TRAIL_LIGHT[1] + nz * TRAIL_LIGHT[2]
        # 单面受光：倒扣（法向朝上）时明显更亮，平飞时偏暗。破 S 先滚转
        # 180° 再俯冲，飘带亮度会先暗后亮，滚转和倒扣一眼就能读出来。
        shade = 0.80 + 0.20 * max(0.0, lit)
        bright = (0.62 + 0.38 * fade) * shade

        # 方向在世界系，先转到相机坐标系再按深度定宽。
        u_cam = (
            ux * self.right[0] + uy * self.right[1] + uz * self.right[2],
            ux * self.up[0] + uy * self.up[1] + uz * self.up[2],
            ux * self.forward[0] + uy * self.forward[1] + uz * self.forward[2],
        )
        depth = 0.5 * (a[2] + b[2])
        half = TRAIL_HALF_PX * depth / self.focal
        ox, oy, oz = (u_cam[0] * half, u_cam[1] * half, u_cam[2] * half)
        ap = (a[0] + ox, a[1] + oy, a[2] + oz)
        am = (a[0] - ox, a[1] - oy, a[2] - oz)
        bp = (b[0] + ox, b[1] + oy, b[2] + oz)
        bm = (b[0] - ox, b[1] - oy, b[2] - oz)
        if min(ap[2], am[2], bp[2], bm[2]) <= NEAR:
            return
        # 横向拆成两半：+y 侧亮、-y 侧暗，形成一条有体积感的带子。飞机滚转
        # 时展向跟着翻转，亮暗边随之交换——这正是“带子翻面”的视觉线索。
        lit_side = tuple(min(255, int(c * bright * 1.15)) for c in base)
        dark_side = tuple(min(255, int(c * bright * 0.86)) for c in base)
        s_a, s_b = self._screen_of(a), self._screen_of(b)
        pygame.draw.polygon(
            self.screen, lit_side,
            [self._screen_of(ap), self._screen_of(bp), s_b, s_a],
        )
        pygame.draw.polygon(
            self.screen, dark_side,
            [self._screen_of(am), self._screen_of(bm), s_b, s_a],
        )
        # 高光芯：中心一条细亮线，远看像发光的航迹，近看有霓虹般的层次。
        core = tuple(min(255, int(c * min(1.45, bright * 1.55))) for c in base)
        pygame.draw.line(self.screen, core, s_a, s_b, 2)

    def _draw_arrow(self, s0, s1, color, size: float = 10.0) -> None:
        """在 s1 处画一个沿 s0→s1 的实心箭标（尾部内凹的细长箭头）。"""
        dx, dy = s1[0] - s0[0], s1[1] - s0[1]
        n = math.hypot(dx, dy)
        if n < 8.0:
            return
        ux, uy = dx / n, dy / n
        # 箭尖在航迹点，箭身向后收；两侧翼点略靠前、尾部中点内凹，
        # 屏幕上就是一个细长的实心箭头，和宽飘带一起读作“带方向的航迹”。
        tip = s1
        back = (s1[0] - ux * size * 2.2, s1[1] - uy * size * 2.2)
        left = (s1[0] - ux * size * 1.1 - uy * size * 0.62,
                s1[1] - uy * size * 1.1 + ux * size * 0.62)
        right = (s1[0] - ux * size * 1.1 + uy * size * 0.62,
                 s1[1] - uy * size * 1.1 - ux * size * 0.62)
        pygame.draw.polygon(self.screen, color, [tip, left, back, right])

    def _draw_gun_envelopes(self, world: World) -> None:
        """机炮包线画成机体所在高度的水平圆环，透视后自然成椭圆。"""
        self.overlay.fill((0, 0, 0, 0))
        for i, ac in enumerate(world.acs):
            if not ac.alive:
                continue
            color = TEAM_COLORS[i]
            radius = ac.spec.gun_range
            for scale, alpha in ((1.0, 40), (0.5, 24)):
                ring: list[tuple[float, float]] = []
                for step in range(49):
                    ang = 2.0 * math.pi * step / 48.0
                    p = (
                        ac.x + radius * scale * math.cos(ang),
                        ac.y + radius * scale * math.sin(ang),
                        ac.z,
                    )
                    s = self.to_screen(p)
                    if s is not None:
                        ring.append(s)
                if len(ring) >= 2:
                    pygame.draw.lines(self.overlay, (*color, alpha), True, ring, 1)
        self.screen.blit(self.overlay, (0, 0))

    # ---------- 机体模型与开火特效 ----------

    def _model_frame(self, ac):
        """返回 (模型, 缩放系数, 姿态, 相机深度)。缩放按屏幕像素长度反推。

        两机共用同一个参考长度 REF_LENGTH 反算屏幕尺寸，于是 F-16（15.06 m）
        在画面上就是 Su-57（20.1 m）的 0.75 倍，保持真实尺寸比例。
        """
        depth = self._view((ac.x, ac.y, ac.z))[2]
        if depth <= NEAR:
            return None
        model = MODEL_BY_NAME.get(ac.spec.name, GENERIC_MODEL)
        # 远距离时保持一个最小可见尺寸，近距也不至于铺满屏幕。
        # 55000 m 的空域尺度下开局两机距离可达 45 km 以上，下限提到 2.0 倍
        # 才能保证远处仍能看清机体轮廓（约 80 px），近距约 120 px。
        target_px = 40.0 * clamp(8000.0 / depth, 2.0, 3.0)
        k = target_px * depth / (self.focal * REF_LENGTH)
        return model, k, attitude_of(ac), depth

    def _model_world(self, ac, att, p, k):
        """机体系点 → 世界坐标，按当前姿态旋转并平移到机体位置。"""
        xb, yb, zb = body_axes(*att)
        u, v, w = p[0] * k, p[1] * k, p[2] * k
        return (
            ac.x + xb[0] * u + yb[0] * v + zb[0] * w,
            ac.y + xb[1] * u + yb[1] * v + zb[1] * w,
            ac.z + xb[2] * u + yb[2] * v + zb[2] * w,
        )

    def _draw_model(self, ac, team: int, frame) -> None:
        model, k, att, _depth = frame
        cull = model.get("cull", True)
        faces = []
        for pts, kind in model["faces"]:
            wp = [self._model_world(ac, att, p, k) for p in pts]
            vp = [self._view(p) for p in wp]
            if any(p[2] <= NEAR for p in vp):
                continue
            poly = [self._screen_of(p) for p in vp]
            normal = _norm(
                _cross(
                    (wp[1][0] - wp[0][0], wp[1][1] - wp[0][1], wp[1][2] - wp[0][2]),
                    (wp[2][0] - wp[0][0], wp[2][1] - wp[0][1], wp[2][2] - wp[0][2]),
                )
            )
            light = 0.62 + 0.38 * abs(_dot(normal, LIGHT))
            # 程序化部件都是封闭体，统一剔除背面，避免远近侧面互相覆盖；
            # OBJ 模型的绕序不统一，按双面绘制（远面先画、近面覆盖）。
            if cull:
                cx = sum(p[0] for p in wp) / len(wp)
                cy = sum(p[1] for p in wp) / len(wp)
                cz = sum(p[2] for p in wp) / len(wp)
                to_eye = (self.eye[0] - cx, self.eye[1] - cy, self.eye[2] - cz)
                if _dot(normal, to_eye) <= 0.0:
                    continue
            if kind == "canopy":
                base = CANOPY_COLOR
            elif kind == "intake":
                base = INTAKE_COLOR
            elif kind == "nozzle":
                base = NOZZLE_COLOR
            else:
                base = tuple(c * PART_SHADE[kind] for c in TEAM_COLORS[team])
            color = tuple(int(clamp(c * light, 0, 255)) for c in base)
            depth = sum(p[2] for p in vp) / len(vp)
            faces.append((depth, poly, color))

        # 尾焰和机体一起参与深度排序，近面能盖住离镜头更远的焰流。
        faces.extend(self._flame_faces(ac, model, k, att, team, _depth))

        # 画家算法：远的先画，近的覆盖上去。
        faces.sort(key=lambda f: -f[0])
        outline = model.get("outline", True)
        for _d, poly, color in faces:
            pygame.draw.polygon(self.screen, color, poly)
            if not outline:
                continue
            # OBJ 模型简化后单个面只有零点几像素，再描边会糊成一团黑，只给大面描边。
            xs = [p[0] for p in poly]
            ys = [p[1] for p in poly]
            if max(max(xs) - min(xs), max(ys) - min(ys)) >= 6.0:
                pygame.draw.polygon(self.screen, (10, 12, 16), poly, 1)

    def _flame_faces(self, ac, model, k, att, team, depth) -> list:
        """尾焰：沿机尾方向铺开的锥形，长度跟随机体加速度（加速变长、减速变短）。"""
        engines = model.get("engines")
        if not engines:
            return []
        nose = self._model_world(ac, att, (model["length"] / 2.0, 0.0, 0.0), k)
        ns = self.to_screen(nose)
        if ns is None:
            return []

        level = self._flame[team]
        ab = clamp(getattr(ac, "ab", 0.0), 0.0, 1.0)
        # 加力时焰色从橙黄偏向蓝白，和内芯一起形成明显不同的两档外观。
        outer = _mix((255, 138, 44), (168, 192, 255), 0.55 * ab)
        inner = _mix((255, 238, 196), (238, 244, 255), 0.75 * ab)
        screen_len = k * model["length"] * self.focal / max(depth, NEAR)
        length = max(3.0, screen_len * (0.06 + 0.20 * level))
        width = max(1.4, length * 0.22)

        out = []
        for bx, by, bz in engines:
            tail = self._model_world(ac, att, (bx, by, bz), k)
            ts = self.to_screen(tail)
            if ts is None:
                continue
            dx, dy = ts[0] - ns[0], ts[1] - ns[1]
            n = math.hypot(dx, dy)
            if n < 1e-3:
                continue
            ux, uy = dx / n, dy / n
            px, py = -uy, ux
            p0 = (ts[0] + ux * 1.5, ts[1] + uy * 1.5)
            mid = (p0[0] + ux * length * 0.35, p0[1] + uy * length * 0.35)
            tip = (p0[0] + ux * length, p0[1] + uy * length)
            plume_depth = self._view(tail)[2]
            out.append((
                plume_depth,
                [
                    (p0[0] + px * width * 0.5, p0[1] + py * width * 0.5),
                    (mid[0] + px * width, mid[1] + py * width),
                    tip,
                    (mid[0] - px * width, mid[1] - py * width),
                    (p0[0] - px * width * 0.5, p0[1] - py * width * 0.5),
                ],
                outer,
            ))

            # 焰芯更短更窄，颜色接近白蓝，形成内外两层。
            ilen = length * 0.55
            imid = (p0[0] + ux * ilen * 0.35, p0[1] + uy * ilen * 0.35)
            itip = (p0[0] + ux * ilen, p0[1] + uy * ilen)
            iw = width * 0.55
            out.append((
                plume_depth - 0.01,
                [
                    (p0[0] + px * iw * 0.5, p0[1] + py * iw * 0.5),
                    (imid[0] + px * iw, imid[1] + py * iw),
                    itip,
                    (imid[0] - px * iw, imid[1] - py * iw),
                    (p0[0] - px * iw * 0.5, p0[1] - py * iw * 0.5),
                ],
                inner,
            ))
        return out

    def _draw_missiles(self, world: World) -> None:
        """在飞格斗弹：弹体 + 尾迹 + 助推尾焰。命中与否只看内核动力学。"""
        live = [m for m in world.missiles if m.alive]
        if not live:
            self.missile_trails.clear()
            return
        live_ids = {id(m) for m in live}
        for key in [k for k in self.missile_trails if k not in live_ids]:
            del self.missile_trails[key]

        self.overlay.fill((0, 0, 0, 0))
        for m in live:
            pts = self.missile_trails.setdefault(id(m), [])
            p = (m.x, m.y, m.z)
            if not pts or math.dist(pts[-1], p) >= 25.0:
                pts.append(p)
                if len(pts) > 160:
                    del pts[0]

            color = TEAM_COLORS[m.owner]
            dim = tuple(int(c * 0.55) for c in color)
            for a, b in zip(pts, pts[1:]):
                seg = self._clip_segment(a, b)
                if seg is None:
                    continue
                pygame.draw.line(self.overlay, (*dim, 150), seg[0], seg[1], 1)

            s = self.to_screen(p)
            if s is None:
                continue
            depth = self._view(p)[2]
            speed = m.speed
            if speed < 1.0:
                continue
            ux, uy, uz = m.vx / speed, m.vy / speed, m.vz / speed
            ahead = self.to_screen(
                (m.x + ux * 60.0, m.y + uy * 60.0, m.z + uz * 60.0)
            )
            if ahead is None:
                continue
            dx, dy = ahead[0] - s[0], ahead[1] - s[1]
            norm = math.hypot(dx, dy)
            if norm < 0.5:
                continue
            sx, sy = dx / norm, dy / norm

            # 弹体长度按型号缩放：中距弹（R-27R/AIM-7M）明显比格斗弹长。
            size = clamp(
                26.0 * (m.spec.length / 3.0) * 7500.0 / max(depth, NEAR),
                6.0, 42.0,
            )
            tail = (s[0] - sx * size, s[1] - sy * size)
            body_color = color if m.guided else (150, 150, 150)
            pygame.draw.line(
                self.overlay, (*body_color, 255), tail, s, max(2, int(size * 0.16))
            )
            pygame.draw.circle(self.overlay, (255, 245, 210, 255), s, max(1, int(size * 0.10)))

            # 预点火段（RCS 摆姿态）主发动机没点燃，不画尾焰。
            if m.ignited and m.fuel > 0.0:
                flame = size * 0.9
                tip = (tail[0] - sx * flame, tail[1] - sy * flame)
                pygame.draw.line(
                    self.overlay, (255, 176, 70, 220), tail, tip, max(2, int(size * 0.2))
                )
                pygame.draw.line(
                    self.overlay, (255, 244, 200, 235), tail,
                    (tail[0] - sx * flame * 0.45, tail[1] - sy * flame * 0.45), 1
                )
        self.screen.blit(self.overlay, (0, 0))

    def _draw_gunfire(self, world: World) -> None:
        """开火特效：炮口焰 + 沿真实炮线方向的曳光轨迹。"""
        self.overlay.fill((0, 0, 0, 0))
        tick = pygame.time.get_ticks() * 0.001
        for i, ac in enumerate(world.acs):
            if not ac.alive or not ac.firing:
                continue
            frame = self._model_frame(ac)
            if frame is None:
                continue
            model, k, att, _depth = frame
            nose = self._model_world(
                ac, att, (model["length"] / 2.0, 0.0, 0.0), k
            )
            ns = self.to_screen(nose)
            if ns is None:
                continue
            gx, gy, gz = gun_direction(ac)
            length = k * model["length"] * 2.6
            es = self.to_screen(
                (nose[0] + gx * length, nose[1] + gy * length, nose[2] + gz * length)
            )
            if es is None:
                continue

            # 曳光轨迹：外层辉光 + 亮芯。
            pygame.draw.line(self.overlay, (*TEAM_COLORS[i], 46), ns, es, 7)
            pygame.draw.line(self.overlay, (255, 154, 54, 170), ns, es, 3)
            pygame.draw.line(self.overlay, (255, 236, 170, 235), ns, es, 1)

            # 炮口焰：脉动光晕 + 星芒。
            pulse = 0.8 + 0.2 * math.sin(tick * 34.0)
            for radius, alpha in ((12, 36), (8, 80), (5, 160), (3, 235)):
                pygame.draw.circle(
                    self.overlay, (255, 214, 128, alpha), ns,
                    max(1, int(radius * pulse)),
                )
            dx, dy = es[0] - ns[0], es[1] - ns[1]
            norm = math.hypot(dx, dy) or 1.0
            ux, uy = dx / norm, dy / norm
            for span, alpha in ((16, 150), (10, 220)):
                tip = (ns[0] + ux * span, ns[1] + uy * span)
                pygame.draw.line(
                    self.overlay, (255, 245, 200, alpha), ns, tip, 2
                )
                for sign in (1.0, -1.0):
                    side = (
                        ns[0] - uy * span * 0.55 * sign,
                        ns[1] + ux * span * 0.55 * sign,
                    )
                    pygame.draw.line(
                        self.overlay, (255, 200, 120, alpha), ns, side, 1
                    )
        self.screen.blit(self.overlay, (0, 0))

    def _draw_aircraft(self, world: World, agents=None) -> None:
        for i, ac in enumerate(world.acs):
            if not ac.alive:
                continue
            pos = self.to_screen((ac.x, ac.y, ac.z))
            if pos is None:
                continue
            frame = self._model_frame(ac)
            if frame is None:
                continue
            size = clamp(7500.0 / frame[3], 0.55, 2.40)
            color = TEAM_COLORS[i]

            # 竖直投影线 + 地面影子：高度差一眼可见。
            ground = self.to_screen((ac.x, ac.y, world.z_floor))
            if ground is not None:
                dim = tuple(int(c * 0.45) for c in color)
                pygame.draw.line(self.screen, dim, pos, ground, 1)
                pygame.draw.circle(self.screen, dim, ground, max(2, int(4 * size)), 1)

            # 机体本身：按 psi/theta/phi 实时旋转，Su-57 与 F-16V 用各自模型。
            # GPU 模式下机体由 OpenGL 画，2D 层只补屏幕空间的尾焰。
            if self.gpu:
                self._draw_flames(ac, i, frame)
            else:
                self._draw_model(ac, i, frame)

            # 机动原语标签随飞机移动：从机体引一条短线；靠近屏幕边缘时翻到
            # 机体另一侧，不再做贴边夹取（夹取会让标签脱开飞机停在边框上）。
            primitive = getattr(agents[i], "primitive", "PURE") if agents else "PURE"
            tactic = getattr(agents[i], "tactic", "") if agents else ""
            text = f"{tactic}·{primitive} {ac.z:.0f}m" if tactic else f"{primitive} {ac.z:.0f}m"
            label = self.font_small.render(text, True, color)
            tw, th = label.get_size()
            gap = 20.0 * size
            ty = int(pos[1] + (-34.0 if i == 0 else 8.0))
            if ty < 4:
                ty = int(pos[1] + 10.0)
            # 默认挂在机体右侧，只有右边放不下时才翻到左侧，
            # 避免标签在飞机越过画面中线时来回跳。
            if pos[0] + gap + tw <= self.w - 8:
                tx = int(pos[0] + gap)
                ax = tx - 6.0
            else:
                tx = int(pos[0] - gap - tw)
                ax = tx + tw + 6.0
            ay = ty + th / 2.0
            pygame.draw.line(
                self.screen, color, (int(pos[0]), int(pos[1])), (ax, ay), 1
            )
            pygame.draw.rect(self.screen, BG, pygame.Rect(tx - 3, ty - 2, tw + 6, th + 4))
            self.screen.blit(label, (tx, ty))

    def _draw_predictions(self, world: World) -> None:
        """机头前方的轨迹预测点：按当前转弯/爬升率积分，1 s 后的位置。

        连线从机头尖端连到预测点，中间按 0.25 s 采样，所以目标在回旋时
        这条线会跟着弯，而不是像速度切线那样笔直地伸出去。直线飞行时
        预测线自然退化成一条与机头方向重合的短线。
        """
        horizon = 1.0
        samples = 4
        for i, ac in enumerate(world.acs):
            if not ac.alive:
                continue
            nx, ny, nz = nose_direction(ac)
            half = 0.5 * ac.spec.length
            pts = [(ac.x + nx * half, ac.y + ny * half, ac.z + nz * half)]
            for k in range(1, samples + 1):
                pts.append(predict_position(ac, horizon * k / samples, steps=4))
            screen = [self.to_screen(p) for p in pts]
            color = TEAM_COLORS[i]
            dim = _mix(color, BG, 0.35)
            for a, b in zip(screen, screen[1:]):
                if a is None or b is None:
                    continue
                pygame.draw.line(self.screen, dim, a, b, 1)
                pygame.draw.circle(self.screen, color, (int(b[0]), int(b[1])), 2)
            end = screen[-1]
            if end is None:
                continue
            # 1 s 后的落点：外圈 + 中心点，和航迹上的事件标记区分开。
            pygame.draw.circle(
                self.screen, color, (int(end[0]), int(end[1])), 7, 1,
            )
            pygame.draw.circle(
                self.screen, color, (int(end[0]), int(end[1])), 2,
            )

    def _draw_flames(self, ac, team: int, frame) -> None:
        """GPU 模式下尾焰仍画在 2D 层：屏幕空间锥形，叠在机体之上。"""
        model, k, att, depth = frame
        for _d, poly, color in self._flame_faces(ac, model, k, att, team, depth):
            pygame.draw.polygon(self.screen, color, poly)

    def _draw_altitude_ladder(self, world: World) -> None:
        """右侧高度尺：两台飞机在垂直方向的相对位置。"""
        x = self.w - 30
        top, bottom = 150, self.h - 150
        pygame.draw.line(self.screen, BORDER, (x, top), (x, bottom), 1)

        zmin, zmax = world.z_floor, world.z_ceiling
        # 高空场景下 1 km 一格太密，按总高度范围自动换挡。
        step = 1000.0 if zmax - zmin <= 8000.0 else 5000.0
        z = math.ceil(zmin / step) * step
        while z <= zmax:
            sy = bottom - (z - zmin) / (zmax - zmin) * (bottom - top)
            pygame.draw.line(self.screen, GRID, (x - 5, sy), (x + 5, sy), 1)
            label = self.font_small.render(f"{z / 1000:.0f}k", True, SUB)
            self.screen.blit(label, (x - 30, sy - 8))
            z += step

        cap = self.font_small.render("ALT", True, SUB)
        self.screen.blit(cap, (x - 18, top - 20))

        for i, ac in enumerate(world.acs):
            if not ac.alive:
                continue
            sy = bottom - (ac.z - zmin) / (zmax - zmin) * (bottom - top)
            # 红蓝左右错开，高度重合时也能看出是两个点。
            mx = x - 7 if i == 0 else x + 7
            pygame.draw.circle(self.screen, TEAM_COLORS[i], (mx, sy), 4)

    def _draw_hud(self, world: World, paused: bool, agents=None) -> None:
        for i, ac in enumerate(world.acs):
            agent = agents[i] if agents else None
            incoming = sum(
                1 for m in world.missiles if m.alive and m.target == i
            )
            self._draw_aircraft_panel(
                ac, agent, TEAM_COLORS[i], right=(i == 1), incoming=incoming
            )

        a, b = world.acs
        dist = math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)
        line = (
            f"T {world.t:5.1f}s    DIST {dist:5.0f}m    "
            f"dALT {b.z - a.z:+5.0f}m    dE {a.energy - b.energy:6.0f} J/kg"
        )
        surf = self.font.render(line, True, TEXT)
        self.screen.blit(surf, (self.w / 2 - surf.get_width() / 2, self.h - 34))

        hint = "ESC/Q quit    SPACE pause    R reset"
        hs = self.font_small.render(hint, True, SUB)
        self.screen.blit(hs, (self.w / 2 - hs.get_width() / 2, self.h - 58))

        self._draw_missile_status(world)
        self._draw_attitude_panel(world)
        self._draw_fighter_stations(world)

        if paused:
            ps = self.font.render("PAUSED", True, TEXT)
            self.screen.blit(ps, (self.w / 2 - ps.get_width() / 2, 18))

    def _draw_missile_status(self, world: World) -> None:
        """在飞导弹状态：型号、制导状态、速度、到目标距离与三维位置。"""
        live = [m for m in world.missiles if m.alive]
        if not live:
            return
        width, row_h = 476, 15
        height = 8 + row_h * len(live)
        x = self.w // 2 - width // 2
        y = 236
        pygame.draw.rect(self.screen, (26, 29, 34), pygame.Rect(x, y, width, height))
        pygame.draw.rect(self.screen, (88, 94, 104), pygame.Rect(x, y, width, height), 1)

        for k, m in enumerate(live):
            target = world.acs[m.target] if 0 <= m.target < len(world.acs) else None
            d = (
                math.dist((m.x, m.y, m.z), (target.x, target.y, target.z))
                if target is not None else 0.0
            )
            color = TEAM_COLORS[m.owner]
            if not m.guided:
                state = "BALLISTIC"
            elif m.decoy_t > 0.0:
                state = "DECOY"
            elif m.spec.is_arh:
                # 主动弹：中段靠载机雷达/数据链，末段自主截获后发射后不管。
                state = "ACTIVE" if m.active else "MIDCRS"
            elif m.spec.is_sarh:
                state = "ILLUM"
            else:
                state = "GUIDE"
            text = (
                f"{m.spec.name} -> {target.spec.name if target else '-':7s} {state:9s} "
                f"v={m.speed:5.0f}  d={d:6.0f}  "
                f"x={m.x / 1000.0:+6.1f} y={m.y / 1000.0:+6.1f} km  alt={m.z:5.0f} m"
            )
            pygame.draw.circle(
                self.screen, color, (x + 10, y + 8 + k * row_h + 5), 3
            )
            surf = self.font_small.render(text, True, TEXT)
            self.screen.blit(surf, (x + 20, y + 3 + k * row_h))

    def _draw_counters(self, world: World) -> None:
        """在飞干扰物：箔条画白色云团，热诱弹画橙色亮点。"""
        for cm in world.counters:
            if not cm.alive:
                continue
            pos = cm.position
            s = self.to_screen(pos)
            if s is None:
                continue
            depth = max(self._view(pos)[2], NEAR)
            r = clamp(self.focal * 2.6 / depth, 1.5, 6.0)
            if cm.kind == "chaff":
                pygame.draw.circle(self.screen, (206, 208, 214), s, int(r))
                pygame.draw.circle(self.screen, (150, 154, 160), s, int(r), 1)
            else:
                pygame.draw.circle(self.screen, (255, 170, 70), s, int(r * 1.3))

    def _draw_attitude_panel(self, world: World) -> None:
        """顶部中央的姿态框：实时显示双方三维模型、姿态、油门与来袭方向。

        姿态坐标系以地面垂直向上为 Z 轴；机体主体色按队伍区分，被导弹威胁时
        机体表面沿“威胁来向”做队伍色 → 告警红的渐变，越靠近来袭一侧越红。
        油门以滑动条 + 百分比给出，尾焰长度与当前推力（油门/加速度）同步。
        """
        width, height = 440, 205
        px = (self.w - width) // 2
        py = 20
        self._attitude_rects = []
        pygame.draw.rect(self.screen, (26, 29, 34), pygame.Rect(px, py, width, height))
        pygame.draw.rect(self.screen, BORDER, pygame.Rect(px, py, width, height), 1)
        pygame.draw.line(
            self.screen, BORDER, (px + width // 2, py + 6),
            (px + width // 2, py + height - 6), 1,
        )

        half = width // 2
        for i, ac in enumerate(world.acs):
            hx = px + i * half
            color = TEAM_COLORS[i]
            name = self.font_small.render(ac.spec.name, True, color)
            self.screen.blit(name, (hx + 10, py + 5))

            rect = pygame.Rect(hx + 8, py + 22, half - 16, 140)
            self._attitude_rects.append(rect)
            # GPU 模式下机体由 GL 补画，这里只留地面线、Z 轴和尾焰。
            self._draw_attitude_model(
                rect, world, i, ac, color, bodies=not self.gpu
            )

            # 油门滑动条：填充比例即当前功率指令；加力时整条变成白蓝色。
            bx, by, bw, bh = hx + 46, py + 173, 104, 9
            thr = clamp(ac.throttle, 0.0, 1.0) if ac.alive else 0.0
            ab = clamp(getattr(ac, "ab", 0.0), 0.0, 1.0) if ac.alive else 0.0
            pygame.draw.rect(self.screen, (44, 48, 55), pygame.Rect(bx, by, bw, bh))
            pygame.draw.rect(
                self.screen,
                (236, 244, 255) if ab > 0.05 else (255, 168, 64),
                pygame.Rect(bx, by, int(bw * thr), bh),
            )
            pygame.draw.rect(self.screen, SUB, pygame.Rect(bx, by, bw, bh), 1)
            self.screen.blit(self.font_small.render("THR", True, SUB), (hx + 10, by - 2))
            self.screen.blit(
                self.font_small.render(
                    f"{thr * 100:3.0f}%{' AB' if ab > 0.05 else '   '}",
                    True, TEXT,
                ),
                (bx + bw + 8, by - 2),
            )

            # 燃油条：加力油耗远高于军推，条长直接给出剩余油量。
            cap = ac.spec.fuel_capacity
            frac = clamp(ac.fuel / cap, 0.0, 1.0) if cap > 0.0 and ac.alive else 1.0
            fy = py + 192
            pygame.draw.rect(self.screen, (44, 48, 55), pygame.Rect(bx, fy, bw, bh))
            pygame.draw.rect(
                self.screen, (118, 196, 148), pygame.Rect(bx, fy, int(bw * frac), bh)
            )
            pygame.draw.rect(self.screen, SUB, pygame.Rect(bx, fy, bw, bh), 1)
            self.screen.blit(self.font_small.render("FUEL", True, SUB), (hx + 10, fy - 2))
            self.screen.blit(
                self.font_small.render(f"{frac * 100:3.0f}%", True, TEXT),
                (bx + bw + 8, fy - 2),
            )

    def _draw_attitude_model(self, rect, world: World, i: int, ac, color,
                             bodies: bool = True) -> None:
        """在姿态框里画一架迷你 3D 机体：固定等距视角 + 正交投影。

        bodies=False 时只画地面线、Z 轴和尾焰（GPU 模式下机体交给 GL 渲染）。
        """
        model = MODEL_BY_NAME.get(ac.spec.name, GENERIC_MODEL)
        length = model["length"]
        att = attitude_of(ac) if ac.alive else (0.0, 0.0, 0.0)
        xb, yb, zb = body_axes(*att)

        # 固定观察方向（世界系），坐标系以地面 Z 轴向上为基准。
        view, right, up = _attitude_basis()
        cx, cy = rect.centerx, rect.centery + 6
        scale = 108.0 / length

        def to_world(p):
            return (
                xb[0] * p[0] + yb[0] * p[1] + zb[0] * p[2],
                xb[1] * p[0] + yb[1] * p[1] + zb[1] * p[2],
                xb[2] * p[0] + yb[2] * p[1] + zb[2] * p[2],
            )

        def project(p):
            wx = xb[0] * p[0] + yb[0] * p[1] + zb[0] * p[2]
            wy = xb[1] * p[0] + yb[1] * p[1] + zb[1] * p[2]
            wz = xb[2] * p[0] + yb[2] * p[1] + zb[2] * p[2]
            return (
                cx + (wx * right[0] + wy * right[1] + wz * right[2]) * scale,
                cy - (wx * up[0] + wy * up[1] + wz * up[2]) * scale,
                wx * view[0] + wy * view[1] + wz * view[2],
            )

        # 地面参考线与 Z 轴（地面垂直向上），让姿态可读。
        pygame.draw.line(
            self.screen, GRID, (rect.left + 4, rect.bottom - 4),
            (rect.right - 4, rect.bottom - 4), 1,
        )
        zx = rect.left + 12
        pygame.draw.line(
            self.screen, (120, 132, 148), (zx, rect.bottom - 6), (zx, rect.top + 10), 1
        )
        pygame.draw.lines(
            self.screen, (120, 132, 148), False,
            [(zx - 3, rect.top + 15), (zx, rect.top + 9), (zx + 3, rect.top + 15)], 1,
        )
        self.screen.blit(self.font_small.render("Z", True, (150, 162, 178)),
                         (zx + 4, rect.top + 8))

        # 来袭方向：最近一枚仍在制导、指向本机的导弹，投影到机体水平面。
        threat = None
        best_d = 1e18
        for m in world.missiles:
            if not m.alive or m.target != i or not m.guided:
                continue
            d = (m.x - ac.x) ** 2 + (m.y - ac.y) ** 2
            if d < best_d:
                best_d, threat = d, m
        fx = fy = 0.0
        if threat is not None:
            dx, dy = threat.x - ac.x, threat.y - ac.y
            fx = dx * xb[0] + dy * xb[1]
            fy = dx * yb[0] + dy * yb[1]
            n = math.hypot(fx, fy)
            if n > 1e-6:
                fx, fy = fx / n, fy / n

        base_color = color if ac.alive else (96, 100, 108)
        # 告警色取黄橙：红蓝两队本体上用纯红都容易糊在一起，黄橙在两种底色
        # 上都能形成清晰的方向渐变。
        red = (255, 210, 90)

        # 尾焰先画，长度随油门/推力变化，机体会自然盖住焰根。
        if ac.alive and model.get("engines"):
            level = clamp(self._flame[i], 0.0, 1.0)
            ab = clamp(getattr(ac, "ab", 0.0), 0.0, 1.0)
            tail = project((-length / 2.0, 0.0, 0.0))
            tip = project((
                -length / 2.0 - length * (0.10 + 0.34 * level), 0.0, 0.0
            ))
            dx, dy = tip[0] - tail[0], tip[1] - tail[1]
            n = math.hypot(dx, dy)
            if n > 1e-3:
                ux, uy = dx / n, dy / n
                wid = 3.0 + 7.0 * level
                tip2 = (tip[0], tip[1])
                pygame.draw.polygon(
                    self.screen, _mix((255, 138, 44), (168, 192, 255), 0.55 * ab), [
                        (tail[0] - uy * wid, tail[1] + ux * wid),
                        tip2,
                        (tail[0] + uy * wid, tail[1] - ux * wid),
                    ])
                inner = (tail[0] + ux * n * 0.55, tail[1] + uy * n * 0.55)
                pygame.draw.polygon(
                    self.screen, _mix((255, 238, 196), (238, 244, 255), 0.75 * ab), [
                        (tail[0] - uy * wid * 0.4, tail[1] + ux * wid * 0.4),
                        inner,
                        (tail[0] + uy * wid * 0.4, tail[1] - ux * wid * 0.4),
                    ])

        # GPU 模式：机体交给 GL 渲染，2D 层到此为止。
        if not bodies:
            return

        faces = []
        for poly, kind in model["faces"]:
            wp = [to_world(p) for p in poly]
            sp = [project(p) for p in poly]
            center = (
                sum(p[0] for p in wp) / len(wp),
                sum(p[1] for p in wp) / len(wp),
                sum(p[2] for p in wp) / len(wp),
            )
            depth = center[0] * view[0] + center[1] * view[1] + center[2] * view[2]

            # 面法线做固定方向光照，避免纯色剪影。
            e1 = (wp[1][0] - wp[0][0], wp[1][1] - wp[0][1], wp[1][2] - wp[0][2])
            e2 = (wp[2][0] - wp[0][0], wp[2][1] - wp[0][1], wp[2][2] - wp[0][2])
            normal = _norm(_cross(e1, e2))
            light = 0.52 + 0.48 * abs(_dot(normal, LIGHT))

            if kind == "canopy":
                base = CANOPY_COLOR
            elif kind == "intake":
                base = INTAKE_COLOR
            elif kind == "nozzle":
                base = NOZZLE_COLOR
            else:
                base = base_color
            # 威胁渐变：面心在机体受威胁方向上的投影决定红色混入比例。
            if threat is not None:
                bx_ = sum(p[0] for p in poly) / len(poly)
                by_ = sum(p[1] for p in poly) / len(poly)
                t = clamp(
                    0.5 + 0.5 * (bx_ * fx + by_ * fy) / max(length * 0.5, 1e-6),
                    0.0, 1.0,
                )
                mix = 0.85 * t
                base = (
                    base[0] + (red[0] - base[0]) * mix,
                    base[1] + (red[1] - base[1]) * mix,
                    base[2] + (red[2] - base[2]) * mix,
                )
            color_ = tuple(int(clamp(c * light, 0, 255)) for c in base)
            faces.append((depth, [(p[0], p[1]) for p in sp], color_))

        # 画家算法：远的先画，近面覆盖。
        for _depth, pts, color_ in sorted(faces, key=lambda f: f[0]):
            pygame.draw.polygon(self.screen, color_, pts)

    def _draw_aircraft_panel(self, ac, agent, color, right: bool, incoming: int = 0) -> None:
        width, height = 236, 232
        x = self.w - width - 20 if right else 20
        y = 20
        pygame.draw.rect(self.screen, (26, 29, 34), pygame.Rect(x, y, width, height))
        pygame.draw.rect(self.screen, color, pygame.Rect(x, y, width, height), 1)
        pygame.draw.rect(self.screen, color, pygame.Rect(x, y, 4, height))

        name = self.font.render(ac.spec.name, True, color)
        self.screen.blit(name, (x + 14, y + 8))

        line = f"SPD {ac.v:5.1f} m/s   G {ac.n:4.1f}"
        self.screen.blit(self.font_small.render(line, True, TEXT), (x + 14, y + 29))

        line = f"ALT {ac.z:5.0f} m   GAM {math.degrees(ac.gamma):+5.1f}"
        self.screen.blit(self.font_small.render(line, True, SUB), (x + 14, y + 47))

        # 姿态读数与 3D 模型同步，来自同一套 psi/theta/phi。
        _psi, theta, phi = attitude_of(ac)
        line = f"PITCH {math.degrees(theta):+5.1f}   ROLL {math.degrees(phi):+6.1f}"
        self.screen.blit(self.font_small.render(line, True, TEXT), (x + 14, y + 65))

        # 格斗弹余量与导引头状态
        msl = ac.spec.missile
        if msl is not None:
            if ac.locked:
                status, st_color = "LOCK", (255, 214, 96)
            elif ac.lock_timer > 0.0:
                pct = 100.0 * ac.lock_timer / msl.lock_time
                status, st_color = f"SEEK {pct:3.0f}%", (214, 202, 142)
            else:
                status, st_color = "SEEK", SUB
            line = f"MSL {ac.missiles}/{ac.spec.missile_count}  {status}"
            self.screen.blit(self.font_small.render(line, True, st_color), (x + 14, y + 83))
            if incoming:
                warn = self.font_small.render(f"IN {incoming}", True, (255, 122, 88))
                self.screen.blit(
                    warn, (x + width - 14 - warn.get_width(), y + 83)
                )

        # 中距弹余量与雷达跟踪状态（主动弹末段截获前需要载机跟踪）
        rsl = ac.spec.radar_missile
        if rsl is not None:
            if ac.radar_locked:
                rstatus, rcolor = "LOCK", (255, 214, 96)
            elif ac.radar_lock_timer > 0.0:
                pct = 100.0 * ac.radar_lock_timer / rsl.lock_time
                rstatus, rcolor = f"TRK {pct:3.0f}%", (214, 202, 142)
            else:
                rstatus, rcolor = "RDR", SUB
            line = f"RDR {ac.radar_missiles}/{ac.spec.radar_missile_count}  {rstatus}"
            self.screen.blit(self.font_small.render(line, True, rcolor), (x + 14, y + 101))

        # 机动原语已改为跟随飞机的浮动标签，面板这里保留态势与干扰物余量。
        line = f"CH {ac.chaff:2d}  FL {ac.flares:2d}"
        self.screen.blit(self.font_small.render(line, True, SUB), (x + 14, y + 119))
        situation = getattr(agent, "situation", "") if agent else ""
        sit = self.font_small.render(f"SIT {situation}", True, SUB)
        self.screen.blit(sit, (x + width - 14 - sit.get_width(), y + 119))

        # 分层显示：TAC 是战术层（打什么仗），MAN 是机动层（具体怎么飞）。
        tactic = getattr(agent, "tactic", "") if agent else ""
        primitive = getattr(agent, "primitive", "") if agent else ""
        self.screen.blit(
            self.font_small.render(f"TAC {tactic}", True, color), (x + 14, y + 137)
        )
        self.screen.blit(
            self.font_small.render(f"MAN {primitive}", True, TEXT), (x + 14, y + 155)
        )

        # 燃油与功率档位：AB = 加力，MIL = 军推；油尽后只能军推。
        cap = ac.spec.fuel_capacity
        fuel_frac = clamp(ac.fuel / cap, 0.0, 1.0) if cap > 0.0 else 1.0
        ab_on = ac.ab > 0.05
        line = f"FUEL {fuel_frac * 100:3.0f}%  {'AB' if ab_on else 'MIL'}"
        self.screen.blit(
            self.font_small.render(
                line, True, (255, 168, 64) if ab_on else (150, 200, 160)
            ),
            (x + 14, y + 177),
        )

        # HP 条 + 数值
        bx, by, bw, bh = x + 14, y + 203, 132, 12
        pygame.draw.rect(self.screen, (44, 48, 55), pygame.Rect(bx, by, bw, bh))
        ratio = max(0.0, ac.hp / ac.spec.hp_max)
        pygame.draw.rect(self.screen, color, pygame.Rect(bx, by, bw * ratio, bh))

        hp_text = self.font_small.render(f"HP {ac.hp:5.1f}", True, TEXT)
        self.screen.blit(hp_text, (bx + bw + 8, by + bh / 2 - hp_text.get_height() / 2))

    # ---------- 机载座舱显示：雷达屏 + 抬头/头瞄 + 武器显示 ----------
    STATION_W = 340

    def _station_layout(self) -> tuple[int, int, int, int]:
        """座舱面板的高度分配（总高, 抬头显示高, 雷达屏高, 武器显示高）。

        窗口高度可调（录制用 1280×800、观战用 1600×1000），所以按比例分配；
        面板顶端给顶部信息框和中央姿态框留出至少 258 px，避免互相压住。
        """
        total = int(clamp(self.h * 0.62, 430, 620))
        total = min(total, self.h - 64 - 258)
        hud_h = int(clamp(total * 0.43, 172, 268))
        scope_h = int(clamp(total * 0.22, 96, 140))
        # 武器页要容纳标题 + 两栏弹药 + 底部机炮/干扰物行，至少 118 px，
        # 不够时先压雷达屏、再压抬头显示，避免文字溢出面板（1280×800 下最容易溢出）。
        weapon_h = total - 34 - scope_h - 6 - hud_h - 8
        if weapon_h < 118:
            cut = min(118 - weapon_h, scope_h - 88)
            scope_h -= cut
            hud_h -= min(118 - weapon_h - cut, hud_h - 156)
            weapon_h = total - 34 - scope_h - 6 - hud_h - 8
        return total, hud_h, scope_h, weapon_h

    def _draw_fighter_stations(self, world: World) -> None:
        """红方座舱区放左侧、蓝方放右侧，每块含雷达屏、头瞄视野与武器显示。

        目标颜色统一按火控状态：绿=已跟踪但未锁定，黄=正在锁定（可发射），
        红=已完成锁定。这样雷达屏与头瞄里的同一个目标颜色始终一致。
        """
        total, _hud, _scope, _weapon = self._station_layout()
        y = self.h - 64 - total
        left_x = 20
        right_x = self.w - 20 - self.STATION_W
        for i, x in enumerate((left_x, right_x)):
            self._draw_station(
                world, i, pygame.Rect(x, y, self.STATION_W, total)
            )

    def _lock_state(self, ac) -> tuple[tuple[int, int, int], str]:
        red, yellow, green = (255, 80, 72), (255, 212, 96), (116, 232, 150)
        if not ac.alive:
            return red, "LOST"
        if ac.radar_locked:
            return red, "LOCK"
        if ac.radar_lock_timer > 0.0:
            return yellow, "LOCKING"
        if ac.contact >= CONTACT_TRACK:
            return green, "TRACK"
        if ac.contact == CONTACT_DETECT or ac.rwr:
            return green, "DETECT"
        return (86, 170, 118), "SEARCH"

    def _missile_threat(self, world: World, i: int):
        """最近一枚来袭弹的 (相对机头方位, 距离)；没有威胁返回 None。"""
        ac = world.acs[i]
        best = None
        for m in world.missiles:
            if not m.alive or m.target != i:
                continue
            dx, dy, dz = m.x - ac.x, m.y - ac.y, m.z - ac.z
            d = math.sqrt(dx * dx + dy * dy + dz * dz)
            az = wrap_pi(math.atan2(dy, dx) - ac.psi)
            if best is None or d < best[1]:
                best = (az, d)
        return best

    def _alpha_rect(
        self, rect: pygame.Rect, color: tuple[int, int, int], alpha: int
    ) -> None:
        """半透明底：座舱区压在 3D 场景上，不能把后面的空战画面盖死。"""
        surf = pygame.Surface(rect.size, pygame.SRCALPHA)
        surf.fill((color[0], color[1], color[2], alpha))
        self.screen.blit(surf, rect.topleft)

    def _alpha_poly(
        self, rect: pygame.Rect, color: tuple[int, int, int],
        points, alpha: int,
    ) -> None:
        surf = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.polygon(
            surf, (color[0], color[1], color[2], alpha),
            [(x - rect.x, y - rect.y) for x, y in points],
        )
        self.screen.blit(surf, rect.topleft)

    def _draw_station(self, world: World, i: int, rect: pygame.Rect) -> None:
        ac = world.acs[i]
        team = TEAM_COLORS[i]
        lock_color, lock_text = self._lock_state(ac)
        # 玻璃感底衬：偏冷的浅色 + 低透明度，地面网格和航迹能透出来；
        # 透明度不能太低，否则 3D 场景里的机体标签会透过面板和读数叠在一起。
        self._alpha_rect(rect, (20, 30, 44), 140)
        pygame.draw.rect(self.screen, team, rect, 1)
        pygame.draw.rect(self.screen, team, pygame.Rect(rect.x, rect.y, rect.w, 3))

        title = self.font_small.render(
            f"{ac.spec.name}   {'RDR ON' if ac.radar_on else 'RDR SIL'}", True, team
        )
        self.screen.blit(title, (rect.x + 10, rect.y + 6))
        st = self.font_small.render(lock_text, True, lock_color)
        self.screen.blit(st, (rect.right - 10 - st.get_width(), rect.y + 6))
        # 锁定进度：黄灯阶段给一条细填充条，锁定后消失（已变红）
        if ac.radar_lock_timer > 0.0 and not ac.radar_locked:
            rspec = ac.spec.radar_missile
            frac = (
                clamp(ac.radar_lock_timer / max(rspec.lock_time, 1e-6), 0.0, 1.0)
                if rspec is not None else 0.0
            )
            bx, by, bw, bh = rect.right - 106, rect.y + 27, 96, 4
            pygame.draw.rect(self.screen, (44, 48, 55), pygame.Rect(bx, by, bw, bh))
            pygame.draw.rect(
                self.screen, lock_color, pygame.Rect(bx, by, int(bw * frac), bh)
            )

        # 竖排：雷达屏在上、抬头显示器居中、武器显示在下
        _total, hud_h, scope_h, weapon_h = self._station_layout()
        scope_rect = pygame.Rect(rect.x + 8, rect.y + 34, rect.w - 16, scope_h)
        self._draw_scope(world, i, scope_rect)
        hud_rect = pygame.Rect(
            rect.x + 8, scope_rect.bottom + 6, rect.w - 16, hud_h
        )
        self._draw_fwd_hud(world, i, hud_rect)
        weapon_rect = pygame.Rect(
            rect.x + 8, hud_rect.bottom + 8, rect.w - 16, weapon_h
        )
        self._draw_weapon_rows(world, i, weapon_rect)

    def _draw_scope(self, world: World, i: int, rect: pygame.Rect) -> None:
        """本机机头朝上的雷达屏：只有拿到距离级接触才画目标光点。"""
        ac = world.acs[i]
        foe = world.acs[1 - i]
        team = TEAM_COLORS[i]
        lock_color, _ = self._lock_state(ac)
        bg = (7, 15, 11)
        grid = (34, 88, 58)
        dim = (86, 170, 118)
        self._alpha_rect(rect, bg, 90)
        pygame.draw.rect(self.screen, grid, rect, 1)

        cx = rect.centerx
        cy = rect.centery
        radius = min(rect.w, rect.h) // 2 - 20

        # 距离档：有稳定跟踪时缩放到当前距离的 1.35 倍；没有接触时用常用档。
        d = math.dist((ac.x, ac.y, ac.z), (foe.x, foe.y, foe.z))
        if ac.contact >= CONTACT_TRACK and d < 1e8:
            rng = clamp(d * 1.35, 4000.0, max(ac.spec.radar_range, 40000.0))
        else:
            rng = max(ac.spec.radar_range, 40000.0) * 0.6

        for frac in (0.25, 0.5, 0.75, 1.0):
            pygame.draw.circle(
                self.screen, grid, (cx, cy), int(radius * frac), 1
            )
        # 距离档标注放在圆环下缘：目标通常出现在机头方向（画面上方）。
        for frac in (0.5, 1.0):
            label = self.font_small.render(f"{rng * frac / 1000:.0f}", True, dim)
            self.screen.blit(label, (cx + 3, cy + int(radius * frac) - 17))
        pygame.draw.line(self.screen, grid, (cx - radius, cy), (cx + radius, cy), 1)
        pygame.draw.line(self.screen, grid, (cx, cy - radius), (cx, cy + radius), 1)

        # 本机符号：机头朝上的小三角
        pygame.draw.polygon(
            self.screen, team,
            [(cx, cy - 8), (cx - 5, cy + 6), (cx + 5, cy + 6)],
        )

        rel = wrap_pi(math.atan2(foe.y - ac.y, foe.x - ac.x) - ac.psi)
        if ac.contact >= CONTACT_TRACK and foe.alive:
            rr = clamp(d / rng, 0.0, 0.96) * radius
            tx = cx + rr * math.sin(rel)
            ty = cy - rr * math.cos(rel)
            pygame.draw.line(self.screen, lock_color, (cx, cy), (tx, ty), 1)
            pygame.draw.circle(self.screen, lock_color, (int(tx), int(ty)), 4)
            pygame.draw.circle(self.screen, bg, (int(tx), int(ty)), 2)
            tag = self.font_small.render(f"{d / 1000:4.1f}", True, lock_color)
            dz = foe.z - ac.z
            alt = self.font_small.render(f"{dz / 1000:+4.1f}k", True, dim)
            # 标签贴着光点放，但避开边框，避免压住距离环刻度。
            lx = tx + 8
            if lx + tag.get_width() > rect.right - 4:
                lx = tx - 8 - tag.get_width()
            ly = ty - 18
            if ly < rect.y + 4:
                ly = ty + 6
            self.screen.blit(tag, (lx, ly))
            self.screen.blit(alt, (lx, ly + tag.get_height()))
        elif ac.contact == CONTACT_DETECT or ac.rwr:
            az = ac.rwr_az if ac.rwr else rel
            tcol = (255, 96, 88) if ac.rwr else dim
            for sgn in (-1.0, 1.0):
                a = az + sgn * math.radians(4.0)
                pygame.draw.line(
                    self.screen, tcol,
                    (cx + 14 * math.sin(a), cy - 14 * math.cos(a)),
                    (cx + radius * math.sin(a), cy - radius * math.cos(a)), 1,
                )
            tag = "RWR" if ac.rwr else "AZ"
            lab = self.font_small.render(tag, True, tcol)
            ex = cx + (radius - 2) * math.sin(az)
            ey = cy - (radius - 2) * math.cos(az)
            self.screen.blit(lab, (ex - lab.get_width() / 2, ey - 18))
        else:
            lab = self.font_small.render("NO CONTACT", True, dim)
            self.screen.blit(lab, (cx - lab.get_width() / 2, cy + radius - 4))

        # ---- 导弹回波 ----
        # 机载雷达同样能扫到弹体，只是弹体 RCS 小，发现距离按四次方根缩水。
        # 只在雷达开机、弹在机头探测锥内、且距离在探测范围内时显示。
        incoming_seen = False
        if ac.radar_on and ac.spec.radar_range > 0.0:
            nnx, nny, nnz = nose_direction(ac)
            msl_reach = ac.spec.radar_range * rcs_scale(MISSILE_RCS)
            for m in world.missiles:
                if not m.alive:
                    continue
                mx, my, mz = m.x - ac.x, m.y - ac.y, m.z - ac.z
                md = math.sqrt(mx * mx + my * my + mz * mz)
                if md < 1e-6 or md > msl_reach:
                    continue
                if math.acos(clamp(
                    (mx * nnx + my * nny + mz * nnz) / md, -1.0, 1.0
                )) > RADAR_DETECT_FOV:
                    continue
                az = wrap_pi(math.atan2(my, mx) - ac.psi)
                rr = clamp(md / rng, 0.0, 0.96) * radius
                bx = cx + rr * math.sin(az)
                by = cy - rr * math.cos(az)
                # 弹的速度矢量方向（屏幕上机头朝上），用来画指向小三角。
                hdg = wrap_pi(math.atan2(m.vy, m.vx) - ac.psi)
                fx, fy = math.sin(hdg), -math.cos(hdg)
                px, py = math.cos(hdg), math.sin(hdg)
                if m.target == i:
                    incoming_seen = True
                    col = (255, 96, 88)
                    pygame.draw.polygon(
                        self.screen, col,
                        [(bx + 6 * fx, by + 6 * fy),
                         (bx - 4 * fx + 3.5 * px, by - 4 * fy + 3.5 * py),
                         (bx - 4 * fx - 3.5 * px, by - 4 * fy - 3.5 * py)],
                    )
                    tag = self.font_small.render(f"{md / 1000:.1f}", True, col)
                    self.screen.blit(tag, (bx + 8, by - 16))
                else:
                    # 己方在飞弹：浅绿空心点 + 一小段速度矢量（不用队伍色，
                    # 否则红方的己方弹会和来袭弹的红色三角混在一起）。
                    own_msl = (116, 232, 150)
                    pygame.draw.circle(
                        self.screen, own_msl, (int(bx), int(by)), 3, 1
                    )
                    pygame.draw.line(
                        self.screen, own_msl,
                        (bx, by), (bx + 7 * fx, by + 7 * fy), 1,
                    )

        # 来袭导弹：雷达没扫到（关机 / 在探测锥外 / 太远）时只在边缘画红色
        # 测向楔形，不给距离——这时的方位来自 RWR，而不是雷达回波。
        threat = self._missile_threat(world, i)
        if threat is not None and not incoming_seen:
            az = threat[0]
            for sgn in (-1.0, 1.0):
                a = az + sgn * math.radians(3.0)
                pygame.draw.line(
                    self.screen, (255, 80, 72),
                    (cx + (radius - 9) * math.sin(a), cy - (radius - 9) * math.cos(a)),
                    (cx + radius * math.sin(a), cy - radius * math.cos(a)), 2,
                )
            lab = self.font_small.render("MSL", True, (255, 80, 72))
            self.screen.blit(lab, (rect.x + 4, rect.bottom - 19))

    def _draw_fwd_hud(self, world: World, i: int, rect: pygame.Rect) -> None:
        """抬头/头瞄视野：航向带、速度/高度刻度带、俯仰梯、目标与炮线。

        版式按真实战机抬头显示：
        - 顶部航向带（相对地球坐标系），当前航向锁在中央方框里，刻度滚动；
        - 左侧速度带、右侧高度带，当前值同样用方框框住并随数值滚动，
          高度带上另有一个三角标志指向当前高度；
        - 中间的俯仰梯代表机头仰角，整条梯子作为刚体随滚转旋转，中央另有
          一个固定不转的水平标志，用它与梯子的夹角读横滚；
        - 目标框为菱形，机炮准星为圆形，圆心落在外弹道预测的落点上。
        """
        ac = world.acs[i]
        foe = world.acs[1 - i]
        lock_color, _ = self._lock_state(ac)
        _psi, theta, phi = attitude_of(ac)
        cx, cy = rect.centerx, rect.centery + 3
        px_per_deg = clamp(rect.h / 105.0, 1.7, 2.6)
        half = rect.w * 0.5
        nom = math.tan(math.radians(26.0))
        # 地平线与整条俯仰梯当作一个刚体，绕 HUD 中心旋转：
        #   d —— 横线自身的方向（随滚转 φ 转过同样的角）
        #   n —— 与横线垂直、指向屏幕下方的方向，各格沿它等距排布
        # 任意点 = 中心 + 横向偏移·d + 俯仰偏移·n。这样相邻横线的端点连线
        # 永远与横线垂直，滚转时整个梯子保持长方形，不会退化成平行四边形。
        d_x, d_y = math.cos(phi), math.sin(phi)
        n_x, n_y = -math.sin(phi), math.cos(phi)
        # 地平线按俯仰姿态（theta）走，而不是航迹角：大迎角时两者会差几度。
        pitch = math.degrees(theta)
        # 上部留给航向带（含方位尖标），底部留给速度/高度单位标注。
        ladder_top = rect.top + 54
        ladder_bottom = rect.bottom - 24

        def hud_pt(az: float, below: float) -> tuple[float, float]:
            """HUD 坐标 → 屏幕像素：az 沿横线方向，below 是相对机头基准向下的度数。"""
            return (
                cx + az * d_x + below * px_per_deg * n_x,
                cy + az * d_y + below * px_per_deg * n_y,
            )

        def view_pt(az_deg: float, el_deg: float) -> tuple[float, float]:
            """方位角/仰角（度）→ 面板坐标，与俯仰梯共用同一套旋转基准。"""
            return hud_pt(
                math.tan(math.radians(az_deg)) / nom * half * 0.82,
                pitch - el_deg,
            )

        self.screen.set_clip(rect)
        try:
            self._alpha_rect(rect, (14, 30, 44), 110)
            # 地面：地平线以下的半边，随滚转倾斜
            hx, hy = hud_pt(0.0, pitch)
            big = max(rect.w, rect.h) * 3.0
            hl = (hx - big * d_x, hy - big * d_y)
            hr = (hx + big * d_x, hy + big * d_y)
            self._alpha_poly(
                rect, (46, 54, 34),
                [
                    hl, hr,
                    (hr[0] + big * n_x, hr[1] + big * n_y),
                    (hl[0] + big * n_x, hl[1] + big * n_y),
                ], 70,
            )
            # 地平线本体：整条贯穿视野，读起来更像抬头显示器
            pygame.draw.line(self.screen, HUD_GREEN, hl, hr, 1)
            # 俯仰梯：5° 一短线、10° 一长线并标角度，0° 与地平线重合
            for p in range(-40, 45, 5):
                mx, my = hud_pt(0.0, pitch - p)
                if not ladder_top < my < ladder_bottom:
                    continue
                major = p % 10 == 0
                ln = 22.0 if major else 10.0
                col = (104, 190, 146) if major else HUD_DIM
                pygame.draw.line(
                    self.screen, col,
                    (mx - ln * d_x, my - ln * d_y),
                    (mx + ln * d_x, my + ln * d_y), 1,
                )
                if major and p != 0:
                    lab = self.font_small.render(f"{p:+d}", True, (92, 168, 126))
                    self.screen.blit(
                        lab, (int(mx + ln * d_x) + 4, int(my + ln * d_y) - 8)
                    )

            # 水平标志：固定不随横滚转动，它与俯仰梯的夹角就是当前坡度。
            # 中间留空，避免和机炮准星/目标框挤在一起，只留两端的长线加端标。
            pygame.draw.line(self.screen, HUD_MARK, (cx - 44, cy), (cx - 13, cy), 2)
            pygame.draw.line(self.screen, HUD_MARK, (cx + 13, cy), (cx + 44, cy), 2)
            pygame.draw.line(self.screen, HUD_MARK, (cx - 44, cy - 4), (cx - 44, cy + 4), 2)
            pygame.draw.line(self.screen, HUD_MARK, (cx + 44, cy - 4), (cx + 44, cy + 4), 2)

            # 速度/高度刻度带（当前值方框 + 滚动刻度），顶部航向带
            self._speed_tape(rect.left + 2, ladder_top, ladder_bottom, ac.v, cy)
            self._altitude_tape(rect.right - 2, ladder_top, ladder_bottom, ac.z, cy)
            self._heading_tape(rect, math.degrees(ac.psi) % 360.0)

            # 目标框：视场内按真实方位/仰角投影，菱形框；出视场退化为头瞄指引。
            # 若只拿到方位（CONTACT_DETECT，例如雷达被干扰、仅 RWR 告警），
            # 就在航向带上标一个琥珀色三角，并给一行方位读数——不给距离框，
            # 避免把“只知道方向”画成“已经跟踪”。
            if foe.alive:
                dx, dy, dz = foe.x - ac.x, foe.y - ac.y, foe.z - ac.z
                dist = math.sqrt(dx * dx + dy * dy + dz * dz)
                rel = wrap_pi(math.atan2(dy, dx) - ac.psi)
                if ac.contact >= CONTACT_TRACK:
                    elev = math.degrees(math.atan2(dz, math.hypot(dx, dy)))
                    if abs(rel) < math.radians(52.0):
                        tx, ty = view_pt(math.degrees(rel), elev)
                        tx = clamp(tx, rect.left + 96, rect.right - 96)
                        ty = clamp(ty, rect.top + 56, rect.bottom - 26)
                        self._diamond(tx, ty, 9, lock_color)
                        lab = self.font_small.render(f"{dist / 1000:4.1f}", True, lock_color)
                        # 距离读数做成贴菱形上缘的小标签：不管目标框落在哪儿，
                        # 都不会压到俯仰梯的角度标注或右侧高度带。
                        lw = lab.get_width()
                        chip = pygame.Rect(int(tx - lw / 2 - 3), ty - 26, lw + 6, 16)
                        chip.clamp_ip(rect)
                        self._alpha_rect(chip, (10, 22, 18), 205)
                        self.screen.blit(lab, (chip.x + 3, chip.y + 2))
                    else:
                        side = rect.right - 10 if rel > 0.0 else rect.left + 10
                        tri = (
                            [(side, cy - 7), (side, cy + 7),
                             (side - 10 if rel > 0.0 else side + 10, cy)]
                        )
                        pygame.draw.polygon(self.screen, lock_color, tri)
                        lab = self.font_small.render("HMD", True, lock_color)
                        self.screen.blit(
                            lab, (side - lab.get_width() if rel > 0.0 else side,
                                  rect.top + 56)
                        )
                elif ac.contact == CONTACT_DETECT or ac.rwr:
                    brg = (math.degrees(ac.psi) + math.degrees(rel)) % 360.0
                    self._bearing_marker(rect, math.degrees(ac.psi) % 360.0, brg)
                    if self._missile_threat(world, i) is None:
                        lab = self.font_small.render(
                            f"TGT BRG {brg:03.0f}", True, HUD_MARK
                        )
                        band = pygame.Rect(
                            int(cx - lab.get_width() / 2 - 4), rect.bottom - 43,
                            lab.get_width() + 8, 17,
                        )
                        self._alpha_rect(band, (10, 22, 18), 230)
                        self.screen.blit(lab, (band.x + 4, band.y + 2))

            # 机炮准星：圆形框，圆心是弹丸外弹道前推到目标距离后的落点。
            # 圆框压住目标菱形，就说明炮线真的压在目标上。
            fall = self._gun_fall_point(world, i)
            if fall is not None:
                rx, ry, rz = fall[0] - ac.x, fall[1] - ac.y, fall[2] - ac.z
                g_az = math.degrees(wrap_pi(math.atan2(ry, rx) - ac.psi))
                g_el = math.degrees(math.atan2(rz, math.hypot(rx, ry)))
                if abs(g_az) < 52.0:
                    gx_, gy_ = view_pt(g_az, g_el)
                    if (rect.left + 96 < gx_ < rect.right - 96
                            and rect.top + 56 < gy_ < rect.bottom - 26):
                        pygame.draw.circle(
                            self.screen, HUD_MARK, (int(gx_), int(gy_)), 9, 1
                        )
                        for k in range(4):
                            ang = math.pi * 0.5 * k
                            ox, oy = math.cos(ang), math.sin(ang)
                            pygame.draw.line(
                                self.screen, HUD_MARK,
                                (int(gx_ + ox * 11), int(gy_ + oy * 11)),
                                (int(gx_ + ox * 15), int(gy_ + oy * 15)), 1,
                            )
                        pygame.draw.circle(
                            self.screen, HUD_MARK, (int(gx_), int(gy_)), 2
                        )

            # 底部单位标注
            cap = self.font_small.render("SPD m/s", True, HUD_DIM)
            self.screen.blit(cap, (rect.left + 6, rect.bottom - 19))
            cap = self.font_small.render("ALT m", True, HUD_DIM)
            self.screen.blit(cap, (rect.right - 6 - cap.get_width(), rect.bottom - 19))

            # 来袭导弹：红色标记落在相对本机的方位上，底部给方位读数。
            # 读数压在俯仰梯最下面两格上，所以先垫一条深色横幅，避免和
            # “-30 / -40”角度标注叠字。
            threat = self._missile_threat(world, i)
            if threat is not None:
                az, td = threat
                wx = clamp(cx + math.sin(az) * half * 0.8,
                           rect.left + 96, rect.right - 96)
                wy = clamp(cy - math.cos(az) * rect.h * 0.34,
                           rect.top + 56, rect.bottom - 26)
                pygame.draw.circle(self.screen, HUD_WARN, (int(wx), int(wy)), 5)
                lab = self.font_small.render(
                    f"MSL {math.degrees(az):+04.0f}  {td / 1000:4.1f}km",
                    True, HUD_WARN,
                )
                band = pygame.Rect(
                    int(cx - lab.get_width() / 2 - 4), rect.bottom - 43,
                    lab.get_width() + 8, 17,
                )
                self._alpha_rect(band, (10, 22, 18), 230)
                self.screen.blit(lab, (band.x + 4, band.y + 2))
        finally:
            self.screen.set_clip(None)

    # ---------- 抬头显示器的刻度带与读数框 ----------

    def _value_box(self, box: pygame.Rect, text: str) -> None:
        """当前值方框：深底 + 亮框 + 居中数字，刻度带从它后面滚过去。"""
        surf = pygame.Surface(box.size, pygame.SRCALPHA)
        surf.fill((8, 22, 16, 236))
        self.screen.blit(surf, box.topleft)
        pygame.draw.rect(self.screen, HUD_MARK, box, 1)
        t = self.font.render(text, True, HUD_MARK)
        self.screen.blit(
            t, (box.centerx - t.get_width() / 2, box.centery - t.get_height() / 2)
        )

    def _bearing_marker(self, rect: pygame.Rect, hdg: float, brg: float) -> None:
        """仅拿到目标方位时，在顶部航向带上方标一个倒三角（随航向滚动）。

        尖标放在读数框上方的独立窄条里：既不会被 HUD 边框裁掉，也不会和中央
        航向读数框、刻度数字压在一起；目标越接近正前方，尖标越贴近读数框。
        """
        span = 200.0
        px_per_deg = rect.w / span
        delta = ((brg - hdg + 180.0) % 360.0) - 180.0
        x = clamp(rect.centerx + delta * px_per_deg, rect.left + 16, rect.right - 16)
        top = rect.top + 3
        pygame.draw.polygon(
            self.screen, HUD_MARK,
            [(x - 7, top), (x + 7, top), (x, top + 12)],
        )

    def _heading_tape(self, rect: pygame.Rect, hdg: float) -> None:
        """顶部航向带：0° = 世界 +x 轴，顺时针增大（相对地球坐标系）。"""
        y = rect.top + 26
        cx = rect.centerx
        # 面板上沿多留一条窄带，给“仅方位”目标的尖标用（见 _bearing_marker）。
        self._alpha_rect(
            pygame.Rect(rect.left + 2, rect.top + 2, rect.w - 4, 42), (8, 22, 30), 120
        )
        pygame.draw.line(self.screen, HUD_DIM, (rect.left + 6, y), (rect.right - 6, y), 1)
        span = 200.0                       # 面板横向覆盖的航向范围（度）
        px_per_deg = rect.w / span
        for t in range(0, 360, 5):
            delta = ((t - hdg + 180.0) % 360.0) - 180.0
            if abs(delta) > span * 0.5 + 4.0:
                continue
            x = cx + delta * px_per_deg
            if x < rect.left + 6 or x > rect.right - 6:
                continue
            if abs(x - cx) < 32.0:         # 中央被读数框压住，不再画刻度
                continue
            major = t % 30 == 0
            ln = 9 if major else 5
            pygame.draw.line(self.screen, HUD_DIM, (x, y), (x, y - ln), 1)
            if major:
                lab = self.font_small.render(f"{t:03.0f}", True, (100, 176, 136))
                # 左右两端留出“HDG”标签的位置，避免第一个航向数字压在上面
                if x - lab.get_width() * 0.5 < rect.left + 36:
                    continue
                if x + lab.get_width() * 0.5 > rect.right - 10:
                    continue
                self.screen.blit(lab, (x - lab.get_width() / 2, y + 2))
        self._value_box(pygame.Rect(cx - 26, y - 11, 52, 22), f"{hdg:3.0f}")
        self.screen.blit(
            self.font_small.render("HDG", True, HUD_DIM), (rect.left + 6, y + 2)
        )

    def _speed_tape(self, x: int, top: int, bottom: int, v: float, cy: int) -> None:
        """左侧速度带：刻度随速度连续滚动，当前值锁在方框里（滚条式读数）。"""
        px_per_ms = 1.5
        line_x = x + 34
        pygame.draw.line(self.screen, HUD_DIM, (line_x, top), (line_x, bottom), 1)
        lo = v - (cy - top) / px_per_ms
        hi = v - (cy - bottom) / px_per_ms
        k = math.floor(lo / 10.0) * 10.0
        while k <= hi:
            y = cy - (k - v) * px_per_ms
            major = int(k) % 50 == 0
            ln = 7 if major else 4
            pygame.draw.line(self.screen, HUD_DIM, (line_x - ln, y), (line_x, y), 1)
            if major:
                lab = self.font_small.render(f"{k:3.0f}", True, (100, 176, 136))
                self.screen.blit(lab, (x + 2, y - 9))
            k += 10.0
        box = pygame.Rect(x + 46, cy - 11, 44, 22)
        self._value_box(box, f"{v:3.0f}")
        pygame.draw.polygon(
            self.screen, HUD_MARK,
            [(x + 34, cy), (x + 46, cy - 6), (x + 46, cy + 6)],
        )

    def _altitude_tape(self, right: int, top: int, bottom: int, z: float, cy: int) -> None:
        """右侧高度带：刻度随高度滚动，当前值方框 + 三角标志指向当前高度。"""
        px_per_100m = clamp((bottom - top) / 58.0, 2.6, 4.6)
        line_x = right - 34
        pygame.draw.line(self.screen, HUD_DIM, (line_x, top), (line_x, bottom), 1)
        span = (bottom - top) / px_per_100m * 100.0
        lo, hi = z - span * 0.5, z + span * 0.5
        k = math.floor(lo / 100.0) * 100.0
        while k <= hi:
            y = cy - (k - z) / 100.0 * px_per_100m
            major = int(k) % 500 == 0
            ln = 7 if major else 4
            pygame.draw.line(self.screen, HUD_DIM, (line_x, y), (line_x + ln, y), 1)
            if major:
                lab = self.font_small.render(f"{k:5.0f}", True, (100, 176, 136))
                # 当前值方框压住的那一行不再标数字（方框里已经是精确读数）
                if abs(y - cy) > 16:
                    # 标在刻度线左侧：右侧只剩 34 px 到面板边，五位数字摆不下
                    self.screen.blit(lab, (line_x - 9 - lab.get_width(), y - 9))
            k += 100.0
        box = pygame.Rect(right - 90, cy - 11, 44, 22)
        self._value_box(box, f"{z:5.0f}")
        pygame.draw.polygon(
            self.screen, HUD_MARK,
            [(right - 34, cy), (right - 46, cy - 6), (right - 46, cy + 6)],
        )

    def _diamond(self, x: float, y: float, r: float, color) -> None:
        """雷达/头瞄锁定菱形框。"""
        pygame.draw.polygon(
            self.screen, color,
            [(x, y - r), (x + r, y), (x, y + r), (x - r, y)], 1,
        )

    def _gun_fall_point(
        self, world: World, i: int,
    ) -> tuple[float, float, float] | None:
        """机炮弹丸在当前机头指向下的预计落点（世界坐标）。

        与 sim._fire_guns / _integrate_bullets 走同一套外弹道：出膛速度取
        “载机速度 + 炮口初速沿机头”，之后只受二次阻力与重力；阻力系数按
        出膛高度的大气密度冻结（弹丸在机炮有效射程内只飞 1 s 量级，高度
        变化对密度的影响可以忽略）。前推距离取当前目标斜距，没有目视接触
        时按机炮最大射程。
        """
        ac = world.acs[i]
        foe = world.acs[1 - i]
        spec = ac.spec
        if foe.alive:
            dist = math.sqrt(
                (foe.x - ac.x) ** 2 + (foe.y - ac.y) ** 2 + (foe.z - ac.z) ** 2
            )
        else:
            dist = spec.gun_range
        dist = clamp(dist, 300.0, spec.gun_range)
        nx, ny, nz = nose_direction(ac)
        vx, vy, vz = world_velocity(ac)
        area = math.pi * (0.5 * spec.bullet_diameter) ** 2
        drag_k = air_density(ac.z) * 0.30 * area / (2.0 * spec.bullet_mass)
        bx_ = ac.x + nx * spec.length * 0.5
        by_ = ac.y + ny * spec.length * 0.5
        bz_ = ac.z + nz * spec.length * 0.5
        bvx = vx + spec.muzzle_speed * nx
        bvy = vy + spec.muzzle_speed * ny
        bvz = vz + spec.muzzle_speed * nz
        dt = 1.0 / 120.0
        for _ in range(240):          # 最多前推 2 s，已超出机炮有效射程
            sp = math.sqrt(bvx * bvx + bvy * bvy + bvz * bvz)
            bvx -= drag_k * sp * bvx * dt
            bvy -= drag_k * sp * bvy * dt
            bvz -= (drag_k * sp * bvz + G) * dt
            bx_ += bvx * dt
            by_ += bvy * dt
            bz_ += bvz * dt
            r2 = (bx_ - ac.x) ** 2 + (by_ - ac.y) ** 2 + (bz_ - ac.z) ** 2
            if r2 >= dist * dist:
                break
        return (bx_, by_, bz_)

    def _silhouette_raw(self, name: str):
        """加载 OBJ 正交俯视轮廓图（透明底、机头朝上），失败返回 None。"""
        if name in self._sil_raw:
            return self._sil_raw[name]
        surf = None
        path = SILHOUETTE_PATH.get(name)
        if path:
            try:
                surf = pygame.image.load(path).convert_alpha()
            except Exception:
                surf = None
        self._sil_raw[name] = surf
        return surf

    def _aircraft_top_view(self, ac, i: int, box: pygame.Rect) -> None:
        """武器页中央的本机俯视轮廓（由 OBJ 正交投影图着色，机头朝上）。"""
        raw = self._silhouette_raw(ac.spec.name)
        if raw is not None:
            key = (ac.spec.name, i, box.w, box.h)
            sprite = self._sil_cache.get(key)
            if sprite is None:
                k = min(box.w / raw.get_width(), box.h / raw.get_height()) * 0.96
                size = (max(1, int(raw.get_width() * k)),
                        max(1, int(raw.get_height() * k)))
                sprite = pygame.transform.smoothscale(raw, size)
                # 白色填充按队伍色着色，深色描边保持不变。
                sprite.fill(TEAM_COLORS[i], special_flags=pygame.BLEND_RGBA_MULT)
                self._sil_cache[key] = sprite
            self.screen.blit(
                sprite,
                (box.centerx - sprite.get_width() // 2,
                 box.centery - sprite.get_height() // 2),
            )
            return

        # 贴图缺失时退回手绘轮廓，保证没有资源也能显示。
        pts = aircraft_silhouette(ac.spec.name)
        ys = [p[1] for p in pts]
        span = 2.0 * max(abs(min(ys)), abs(max(ys)))
        scale = min(box.w / 1.12, box.h / (span + 0.12))
        cx, cy = box.centerx, box.centery
        poly = [(cx + p[1] * scale, cy - p[0] * scale) for p in pts]
        fill = tuple(int(c * 0.24) for c in TEAM_COLORS[i])
        pygame.draw.polygon(self.screen, fill, poly)
        pygame.draw.polygon(self.screen, TEAM_COLORS[i], poly, 1)
        # 机身中线 + 座舱盖，给俯视轮廓一个朝向参照
        pygame.draw.line(
            self.screen, TEAM_COLORS[i],
            (cx, int(cy - 0.48 * scale)), (cx, int(cy + 0.48 * scale)), 1,
        )
        pygame.draw.circle(
            self.screen, CANOPY_COLOR,
            (cx, int(cy - 0.12 * scale)), max(2, int(0.045 * scale)), 1,
        )
        # 挂点：先按站位求出机翼在该处的弦长，短线只落在弦内，
        # 避免按固定前后位置画时短线戳出机身轮廓。
        for f in (-0.66, -0.32, 0.32, 0.66):
            sy = f * span * 0.5
            xs: list[float] = []
            for a, b in zip(pts, pts[1:] + pts[:1]):
                if (a[1] - sy) * (b[1] - sy) > 0.0 or a[1] == b[1]:
                    continue
                t = (sy - a[1]) / (b[1] - a[1])
                xs.append(a[0] + t * (b[0] - a[0]))
            if len(xs) < 2:
                continue
            mx = 0.5 * (min(xs) + max(xs))
            sx = cx + sy * scale
            pygame.draw.line(
                self.screen, (198, 226, 210),
                (sx, cy - (mx - 0.045) * scale),
                (sx, cy - (mx + 0.045) * scale), 1,
            )

    def _draw_missile_icon(self, x: float, y: float, color) -> None:
        """4×12 的小弹体剪影（鼻锥 + 弹体 + 尾翼），武器页的弹种 logo。"""
        xi, yi = int(x), int(y)
        pygame.draw.polygon(
            self.screen, color, [(xi + 2, yi), (xi + 4, yi + 4), (xi, yi + 4)]
        )
        pygame.draw.rect(self.screen, color, pygame.Rect(xi, yi + 4, 4, 5))
        pygame.draw.line(self.screen, color, (xi, yi + 9), (xi + 4, yi + 9), 1)
        pygame.draw.line(self.screen, color, (xi, yi + 12), (xi + 2, yi + 9), 1)
        pygame.draw.line(self.screen, color, (xi + 4, yi + 12), (xi + 2, yi + 9), 1)

    def _draw_weapon_rows(self, world: World, i: int, rect: pygame.Rect) -> None:
        """武器显示页（MFD 风格）：中央本机俯视轮廓 + 两侧挂点余量。

        版式参考机载武器页：黑底亮线，中间画本机俯视轮廓（Su-57 / F-16
        各自按真实俯视图的轮廓），左右各列一栏弹药，底部一行机炮与干扰物。
        每栏只占两行（口径标签 + “弹名 余量/总量”），行距随面板高度收敛，
        这样 1280×800 的小面板里也不会溢出到底部行。
        """
        ac = world.acs[i]
        team = TEAM_COLORS[i]
        self._alpha_rect(rect, (5, 15, 11), 214)
        pygame.draw.rect(self.screen, team, rect, 1)
        self.screen.blit(
            self.font_small.render("WPN", True, (104, 202, 150)),
            (rect.x + 8, rect.y + 4),
        )
        inflight = sum(1 for m in world.missiles if m.alive and m.owner == i)
        threat = self._missile_threat(world, i)
        if threat is not None:
            tag, tcol = f"MSL {threat[1] / 1000:.1f}", HUD_WARN
        elif inflight:
            tag, tcol = f"IN {inflight}", HUD_MARK
        else:
            tag, tcol = "CLEAR", (104, 202, 150)
        t = self.font_small.render(tag, True, tcol)
        self.screen.blit(t, (rect.right - 8 - t.get_width(), rect.y + 4))

        self._aircraft_top_view(
            ac, i,
            pygame.Rect(rect.x + 86, rect.y + 18, rect.w - 172, rect.h - 38),
        )

        dim = (140, 178, 158)
        empty = (196, 156, 104)
        name_col = (208, 232, 218)

        # 左栏：中距弹；右栏：格斗弹
        groups = (
            ("AAM-R", ac.spec.radar_missile, ac.radar_missiles,
             ac.spec.radar_missile_count, True),
            ("AAM-IR", ac.spec.missile, ac.missiles,
             ac.spec.missile_count, False),
        )
        row_gap = clamp((rect.h - 40) / 2.0, 24, 34)
        for k, (title, spec, have, total, left) in enumerate(groups):
            if spec is None:
                continue
            y = rect.y + 22 + k * row_gap
            x = rect.x + 8 if left else rect.right - 8
            head = self.font_small.render(title, True, dim)
            self.screen.blit(head, (x if left else x - head.get_width(), y))
            # 弹体 logo：一排小弹体剪影，已挂载的亮、已打掉的压暗，
            # 让“还剩几枚”在一眼扫过时就能读出来。
            slots = min(int(total), 4)
            icons_w = slots * 6 - 2
            iy = y + 1
            if left:
                ix = x + head.get_width() + 6
            else:
                ix = x - head.get_width() - 6 - icons_w
            for s in range(slots):
                col = team if s < int(have) else (72, 92, 84)
                self._draw_missile_icon(ix + s * 6, iy, col)
            tag = self.font_small.render(f"{spec.name} {have}/{total}", True,
                                         name_col if have else empty)
            self.screen.blit(tag, (x if left else x - tag.get_width(), y + 14))

        by = rect.bottom - 19
        gun = self.font_small.render(f"GUN {int(ac.ammo)}", True, dim)
        self.screen.blit(gun, (rect.x + 8, by))
        cm = self.font_small.render(
            f"CH {ac.chaff}  FL {ac.flares}", True, dim
        )
        self.screen.blit(cm, (rect.right - 8 - cm.get_width(), by))


    def _draw_result(self, world: World) -> None:
        self.overlay.fill((8, 9, 11, 190))
        self.screen.blit(self.overlay, (0, 0))

        if world.result == "draw":
            title, color = "DRAW", TEXT
            detail_text = (
                "mutual kill" if world.reason_code == "kill"
                else "time-up, HP even"
            )
        else:
            idx = 0 if world.result == "red" else 1
            loser = world.acs[1 - idx].spec.name
            title, color = f"{world.acs[idx].spec.name} WINS", TEAM_COLORS[idx]
            detail_text = {
                "kill": f"{loser} shot down",
                "boundary": f"{loser} out of bounds",
                "timeout": "time-up, HP advantage",
            }.get(world.reason_code, "")

        surf = self.font_big.render(title, True, color)
        self.screen.blit(surf, (self.w / 2 - surf.get_width() / 2, self.h / 2 - 60))

        detail = self.font.render(detail_text, True, TEXT)
        self.screen.blit(detail, (self.w / 2 - detail.get_width() / 2, self.h / 2 + 10))

        tip = self.font_small.render("press R to restart", True, SUB)
        self.screen.blit(tip, (self.w / 2 - tip.get_width() / 2, self.h / 2 + 42))

    # ---------- GPU 渲染（OpenGL 3.3 core / moderngl） ----------

    def _init_gpu(self, size: tuple[int, int]) -> bool:
        """尝试建立 GL 上下文并初始化渲染资源；失败返回 False。"""
        try:
            import moderngl
        except Exception:
            return False
        try:
            pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 3)
            pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 3)
            pygame.display.gl_set_attribute(
                pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE
            )
            pygame.display.gl_set_attribute(pygame.GL_DEPTH_SIZE, 24)
            pygame.display.gl_set_attribute(pygame.GL_DOUBLEBUFFER, 1)
            pygame.display.set_mode(size, pygame.OPENGL | pygame.DOUBLEBUF)
            ctx = moderngl.create_context()
        except Exception:
            # 没有可用的 GL（远程会话 / 纯软件驱动）：重开显示，交给 CPU 路径。
            pygame.display.quit()
            pygame.display.init()
            return False

        self.mgl = moderngl
        self.ctx = ctx
        self.lit_prog = ctx.program(vertex_shader=LIT_VS, fragment_shader=LIT_FS)
        self.flat_prog = ctx.program(vertex_shader=FLAT_VS, fragment_shader=LIT_FS)
        self.hud_prog = ctx.program(vertex_shader=HUD_VS, fragment_shader=HUD_FS)
        self.lit_prog["u_light"].value = LIGHT
        self.hud_prog["u_tex"].value = 0

        # HUD 合成用的全屏四边形：翻转上传纹理，使 v=0 对应画面底部。
        quad = array("f", (
            -1.0, -1.0, 0.0, 0.0,  1.0, -1.0, 1.0, 0.0,  1.0, 1.0, 1.0, 1.0,
            -1.0, -1.0, 0.0, 0.0,  1.0, 1.0, 1.0, 1.0,  -1.0, 1.0, 0.0, 1.0,
        )).tobytes()
        self._hud_vbo = ctx.buffer(quad)
        self.hud_vao = ctx.vertex_array(
            self.hud_prog, [(self._hud_vbo, "2f 2f", "in_pos", "in_uv")]
        )
        # 姿态框模型先渲到离屏纹理，再按面板矩形贴回来。
        self._panel_vbo = ctx.buffer(reserve=6 * 4 * 4)
        self._panel_vao = ctx.vertex_array(
            self.hud_prog, [(self._panel_vbo, "2f 2f", "in_pos", "in_uv")]
        )
        self.hud_tex = ctx.texture(size, 4)
        self.hud_tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        # 地面城市地图：逐帧按相机投影生成低分辨率图层，再由 GL 线性放大。
        self._ground_tex = None

        self._meshes: dict = {}
        self._trail_buf: list = [None, None]
        self._floor = None
        self._panel_fbo = None
        self._panel_tex = None
        self._panel_size = None
        # GPU 模式下 self.screen 指向透明 HUD 面，所有 2D 绘制都落在这里。
        self.screen = self.hud = pygame.Surface(size, pygame.SRCALPHA)
        return True

    def _proj_mat(self, near: float, far: float):
        """透视投影：与 CPU 的 focal 一致，屏幕坐标可直接对齐。

        采用 +z 朝前的相机系，深度在 [near, far] 上映射到 [-1, 1]。
        """
        a = 2.0 * self.focal / self.w
        b = 2.0 * self.focal / self.h
        return (
            (a, 0.0, 0.0, 0.0),
            (0.0, b, 0.0, 0.0),
            (0.0, 0.0, (far + near) / (far - near),
             -2.0 * far * near / (far - near)),
            (0.0, 0.0, 1.0, 0.0),
        )

    def _view_mat(self):
        e, r, u, fw = self.eye, self.right, self.up, self.forward
        return (
            (r[0], r[1], r[2], -_dot(r, e)),
            (u[0], u[1], u[2], -_dot(u, e)),
            (fw[0], fw[1], fw[2], -_dot(fw, e)),
            (0.0, 0.0, 0.0, 1.0),
        )

    def _floor_vao(self, arena: float, z_floor: float):
        """最低高度层网格 + 空域边界，按 (arena, z_floor) 缓存一次。"""
        key = (arena, z_floor)
        if self._floor is not None:
            if self._floor[3] == key:
                return self._floor[0]
            self._floor[0].release()
            self._floor[1].release()
        half = arena / 2.0
        # 与 CPU 版 _draw_floor 保持一致：贴了城市地图后网格放到 4 km。
        step = 4000.0
        grid = tuple(c / 255.0 for c in GRID)
        edge = tuple(c / 255.0 for c in BORDER)
        verts: list[float] = []

        def add(p, col):
            verts.extend((p[0], p[1], p[2], col[0], col[1], col[2]))

        n = int(round(arena / step))
        for k in range(n + 1):
            t = -half + k * step
            add((t, -half, z_floor), grid)
            add((t, half, z_floor), grid)
            add((-half, t, z_floor), grid)
            add((half, t, z_floor), grid)
        corners = [(-half, -half), (half, -half), (half, half), (-half, half)]
        for i in range(4):
            add((*corners[i], z_floor), edge)
            add((*corners[(i + 1) % 4], z_floor), edge)

        buf = self.ctx.buffer(array("f", verts).tobytes())
        vao = self.ctx.vertex_array(
            self.flat_prog, [(buf, "3f 3f", "in_pos", "in_col")]
        )
        self._floor = (vao, buf, len(verts) // 6, key)
        return vao

    def _trail_vao(self, i: int, trail):
        """航迹折线：只在采样点增加时重建缓冲。"""
        if len(trail) < 2:
            return None
        slot = self._trail_buf[i]
        if slot is not None and slot[2] == len(trail):
            return slot[0]
        if slot is not None:
            slot[0].release()
            slot[1].release()
        col = tuple(c / 255.0 * 0.92 for c in TEAM_COLORS[i])
        verts: list[float] = []
        for p in trail:
            verts.extend((p[0], p[1], p[2], col[0], col[1], col[2]))
        buf = self.ctx.buffer(array("f", verts).tobytes())
        vao = self.ctx.vertex_array(
            self.flat_prog, [(buf, "3f 3f", "in_pos", "in_col")]
        )
        self._trail_buf[i] = (vao, buf, len(trail))
        return vao

    def _mesh_vao(self, model, team: int):
        """把机体模型烘成三角网格：顶点色 + 面法线，按 (模型, 队伍) 缓存。"""
        key = (id(model), team)
        hit = self._meshes.get(key)
        if hit is not None:
            return hit[0]
        verts: list[float] = []
        for pts, kind in model["faces"]:
            if len(pts) < 3:
                continue
            if kind == "canopy":
                base = CANOPY_COLOR
            elif kind == "intake":
                base = INTAKE_COLOR
            elif kind == "nozzle":
                base = NOZZLE_COLOR
            else:
                shade = PART_SHADE.get(kind, 1.0)
                base = tuple(int(c * shade) for c in TEAM_COLORS[team])
            rgb = (base[0] / 255.0, base[1] / 255.0, base[2] / 255.0)
            e1 = (pts[1][0] - pts[0][0], pts[1][1] - pts[0][1],
                  pts[1][2] - pts[0][2])
            e2 = (pts[2][0] - pts[0][0], pts[2][1] - pts[0][1],
                  pts[2][2] - pts[0][2])
            nx, ny, nz = _cross(e1, e2)
            ln = math.sqrt(nx * nx + ny * ny + nz * nz)
            if ln < 1e-9:
                nx, ny, nz = 0.0, 0.0, 1.0
            else:
                nx, ny, nz = nx / ln, ny / ln, nz / ln
            # 多边形按扇形三角化，OBJ 的绕序不统一，统一双面绘制由法线取绝对值处理。
            for j in range(1, len(pts) - 1):
                for p in (pts[0], pts[j], pts[j + 1]):
                    verts.extend((
                        p[0], p[1], p[2], nx, ny, nz, rgb[0], rgb[1], rgb[2],
                    ))
        if not verts:
            return None
        buf = self.ctx.buffer(array("f", verts).tobytes())
        vao = self.ctx.vertex_array(
            self.lit_prog, [(buf, "3f 3f 3f", "in_pos", "in_nrm", "in_col")]
        )
        self._meshes[key] = (vao, buf)
        return vao

    def _model_matrix(self, ac, att, scale: float):
        """机体系 → 世界系：机体三轴按姿态旋转、整体缩放并平移到机体位置。"""
        xb, yb, zb = body_axes(*att)
        return (
            (scale * xb[0], scale * yb[0], scale * zb[0], ac.x),
            (scale * xb[1], scale * yb[1], scale * zb[1], ac.y),
            (scale * xb[2], scale * yb[2], scale * zb[2], ac.z),
            (0.0, 0.0, 0.0, 1.0),
        )

    def _gpu_ground(self, world: World) -> None:
        """把城市地图地面层作为全屏纹理画在 3D 场景最底层。"""
        surf = self._ground_image(world)
        if surf is None:
            return
        ctx, mgl = self.ctx, self.mgl
        size = surf.get_size()
        if self._ground_tex is None or tuple(self._ground_tex.size) != size:
            if self._ground_tex is not None:
                self._ground_tex.release()
            self._ground_tex = ctx.texture(size, 4)
            self._ground_tex.filter = (mgl.LINEAR, mgl.LINEAR)
        self._ground_tex.write(pygame.image.tobytes(surf, "RGBA", True))
        ctx.disable(mgl.DEPTH_TEST)
        ctx.enable(mgl.BLEND)
        ctx.blend_func = mgl.SRC_ALPHA, mgl.ONE_MINUS_SRC_ALPHA
        self._ground_tex.use(0)
        self.hud_prog["u_tex"].value = 0
        self.hud_vao.render(mgl.TRIANGLES)

    def _gpu_scene(self, world: World) -> None:
        """3D 场景：地面网格、双方航迹、两架机体。"""
        ctx, mgl = self.ctx, self.mgl
        ctx.viewport = (0, 0, self.w, self.h)
        ctx.clear(BG[0] / 255.0, BG[1] / 255.0, BG[2] / 255.0, 1.0)
        self._gpu_ground(world)
        ctx.enable(mgl.DEPTH_TEST)
        ctx.disable(mgl.CULL_FACE)
        ctx.disable(mgl.BLEND)

        # 近裁剪面跟着取景距离走：几十公里外看机体时，近平面太小会让
        # 24 位深度在这个距离上几乎全部量化到同一个值（面片互相穿插）。
        near = max(20.0, self.dist * 0.02)
        far = max(self.dist * 8.0, world.arena * 1.6)
        pv = _mat4_mul(self._proj_mat(near, far), self._view_mat())

        self.flat_prog["u_mvp"].value = _mat4_flat(pv)
        self._floor_vao(world.arena, world.z_floor).render(mgl.LINES)

        for i, trail in enumerate(self.trails):
            vao = self._trail_vao(i, trail)
            if vao is not None:
                vao.render(mgl.LINE_STRIP)

        for i, ac in enumerate(world.acs):
            if not ac.alive:
                continue
            frame = self._model_frame(ac)
            if frame is None:
                continue
            model, k, att, _depth = frame
            vao = self._mesh_vao(model, i)
            if vao is None:
                continue
            xb, yb, zb = body_axes(*att)
            rot = (
                (xb[0], yb[0], zb[0], 0.0),
                (xb[1], yb[1], zb[1], 0.0),
                (xb[2], yb[2], zb[2], 0.0),
                (0.0, 0.0, 0.0, 1.0),
            )
            self.lit_prog["u_mvp"].value = _mat4_flat(
                _mat4_mul(pv, self._model_matrix(ac, att, k))
            )
            self.lit_prog["u_rot"].value = _mat4_flat(rot)
            vao.render(mgl.TRIANGLES)

    def _gpu_hud(self) -> None:
        """把 pygame 画好的 HUD 面作为 RGBA 纹理叠在 3D 画面上。"""
        ctx, mgl = self.ctx, self.mgl
        ctx.viewport = (0, 0, self.w, self.h)
        ctx.disable(mgl.DEPTH_TEST)
        ctx.enable(mgl.BLEND)
        ctx.blend_func = mgl.SRC_ALPHA, mgl.ONE_MINUS_SRC_ALPHA
        self.hud_tex.write(pygame.image.tobytes(self.hud, "RGBA", True))
        self.hud_tex.use(0)
        self.hud_vao.render(mgl.TRIANGLES)

    def _panel_target(self, size):
        """姿态框用的离屏缓冲：自带深度，避免和主场景的深度缓冲互相干扰。"""
        if self._panel_fbo is not None and self._panel_size == size:
            return self._panel_fbo
        if self._panel_fbo is not None:
            self._panel_fbo.release()
            self._panel_tex.release()
        tex = self.ctx.texture(size, 4)
        tex.filter = (self.mgl.NEAREST, self.mgl.NEAREST)
        fbo = self.ctx.framebuffer(
            color_attachments=[tex],
            depth_attachment=self.ctx.depth_texture(size),
        )
        self._panel_tex, self._panel_fbo, self._panel_size = tex, fbo, size
        return fbo

    def _gpu_attitude(self, world: World) -> None:
        """在顶部姿态框里补画两架迷你机体（固定等距视角的正交投影）。"""
        if not self._attitude_rects:
            return
        ctx, mgl = self.ctx, self.mgl
        view, right, up = _attitude_basis()
        view_mat = (
            (right[0], right[1], right[2], 0.0),
            (up[0], up[1], up[2], 0.0),
            (view[0], view[1], view[2], 0.0),
            (0.0, 0.0, 0.0, 1.0),
        )
        for i, rect in enumerate(self._attitude_rects):
            ac = world.acs[i]
            if not ac.alive:
                continue
            model = MODEL_BY_NAME.get(ac.spec.name, GENERIC_MODEL)
            vao = self._mesh_vao(model, i)
            if vao is None:
                continue
            att = attitude_of(ac)
            scale = 108.0 / model["length"]
            xb, yb, zb = body_axes(*att)
            rot = (
                (xb[0], yb[0], zb[0], 0.0),
                (xb[1], yb[1], zb[1], 0.0),
                (xb[2], yb[2], zb[2], 0.0),
                (0.0, 0.0, 0.0, 1.0),
            )
            proj = (
                (2.0 / rect.width, 0.0, 0.0, 0.0),
                (0.0, 2.0 / rect.height, 0.0, 0.0),
                (0.0, 0.0, 1.0 / 2000.0, 0.0),
                (0.0, 0.0, 0.0, 1.0),
            )
            # 与 2D 版本一致：模型中心在面板中心下方 6 px。
            shift = (
                (1.0, 0.0, 0.0, 0.0),
                (0.0, 1.0, 0.0, -6.0),
                (0.0, 0.0, 1.0, 0.0),
                (0.0, 0.0, 0.0, 1.0),
            )
            model_mat = (
                (scale * xb[0], scale * yb[0], scale * zb[0], 0.0),
                (scale * xb[1], scale * yb[1], scale * zb[1], 0.0),
                (scale * xb[2], scale * yb[2], scale * zb[2], 0.0),
                (0.0, 0.0, 0.0, 1.0),
            )
            mvp = _mat4_mul(proj, _mat4_mul(shift, _mat4_mul(view_mat, model_mat)))

            fbo = self._panel_target((rect.width, rect.height))
            fbo.use()
            ctx.viewport = (0, 0, rect.width, rect.height)
            ctx.clear(0.0, 0.0, 0.0, 0.0, 1.0)
            ctx.enable(mgl.DEPTH_TEST)
            ctx.disable(mgl.CULL_FACE)
            ctx.disable(mgl.BLEND)
            self.lit_prog["u_mvp"].value = _mat4_flat(mvp)
            self.lit_prog["u_rot"].value = _mat4_flat(rot)
            vao.render(mgl.TRIANGLES)

            # 贴回主画面：面板矩形换算成 NDC，纹理 v=0 在矩形底边。
            ctx.screen.use()
            ctx.viewport = (0, 0, self.w, self.h)
            ctx.disable(mgl.DEPTH_TEST)
            ctx.enable(mgl.BLEND)
            ctx.blend_func = mgl.SRC_ALPHA, mgl.ONE_MINUS_SRC_ALPHA
            x0 = 2.0 * rect.left / self.w - 1.0
            x1 = 2.0 * rect.right / self.w - 1.0
            y0 = 1.0 - 2.0 * rect.bottom / self.h
            y1 = 1.0 - 2.0 * rect.top / self.h
            quad = array("f", (
                x0, y0, 0.0, 0.0,  x1, y0, 1.0, 0.0,  x1, y1, 1.0, 1.0,
                x0, y0, 0.0, 0.0,  x1, y1, 1.0, 1.0,  x0, y1, 0.0, 1.0,
            )).tobytes()
            self._panel_vbo.write(quad)
            self._panel_tex.use(0)
            self._panel_vao.render(mgl.TRIANGLES)
